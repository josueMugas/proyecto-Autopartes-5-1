package com.demografia.controller;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.demografia.dao.FactoryDAO;
import com.demografia.dao.ICompraDAO;
import com.demografia.modelo.CompraResultado;
import java.math.BigDecimal;
import java.sql.SQLException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CompraServletTest extends ServletTestBase {

    private static final String CARRITO = "[{\"idProducto\":1,\"cantidad\":2}]";

    private ICompraDAO dao;
    private CompraServlet servlet;

    @BeforeEach
    void preparar() {
        dao = mock(ICompraDAO.class);
        fabrica.when(FactoryDAO::getCompraDAO).thenReturn(dao);
        servlet = new CompraServlet();
    }

    // ---------- VERDE ----------

    @Test
    void verde_cliente_confirmaCompra() throws Exception {
        sesionDe(usuario(4, 11));
        cuerpo(CARRITO);
        when(dao.confirmarCompra(eq(11), eq(7), anyList()))
                .thenReturn(new CompraResultado(100, new BigDecimal("300"), new BigDecimal("700")));
        servlet.doPost(req, resp);
        verify(dao).confirmarCompra(eq(11), eq(7), anyList());
        assertTrue(respuesta().contains("\"idPresupuesto\":100"));
    }

    // ---------- ROJO ----------

    @Test
    void rojo_sinSesion_responde401() throws Exception {
        sinSesion();
        cuerpo(CARRITO);
        servlet.doPost(req, resp);
        verify(resp).setStatus(401);
        verify(dao, never()).confirmarCompra(anyInt(), anyInt(), anyList());
    }

    @Test
    void rojo_noEsCliente_responde403() throws Exception {
        sesionDe(usuario(1, 0));
        cuerpo(CARRITO);
        servlet.doPost(req, resp);
        verify(resp).setStatus(403);
        verify(dao, never()).confirmarCompra(anyInt(), anyInt(), anyList());
    }

    @Test
    void rojo_clienteSinIdCliente_responde403() throws Exception {
        sesionDe(usuario(4, 0));
        cuerpo(CARRITO);
        servlet.doPost(req, resp);
        verify(resp).setStatus(403);
    }

    @Test
    void rojo_carritoVacio_responde400() throws Exception {
        sesionDe(usuario(4, 11));
        cuerpo("[]");
        servlet.doPost(req, resp);
        verify(resp).setStatus(400);
        verify(dao, never()).confirmarCompra(anyInt(), anyInt(), anyList());
    }

    @Test
    void rojo_cuerpoVacio_responde400() throws Exception {
        sesionDe(usuario(4, 11));
        cuerpo("");
        servlet.doPost(req, resp);
        verify(resp).setStatus(400);
    }

    @Test
    void rojo_jsonMalformado_responde400() throws Exception {
        sesionDe(usuario(4, 11));
        cuerpo("[{no es json");
        servlet.doPost(req, resp);
        verify(resp).setStatus(400);
    }

    @Test
    void rojo_cantidadCero_responde400() throws Exception {
        sesionDe(usuario(4, 11));
        cuerpo("[{\"idProducto\":1,\"cantidad\":0}]");
        servlet.doPost(req, resp);
        verify(resp).setStatus(400);
        verify(dao, never()).confirmarCompra(anyInt(), anyInt(), anyList());
    }

    @Test
    void rojo_productoInvalido_responde400() throws Exception {
        sesionDe(usuario(4, 11));
        cuerpo("[{\"idProducto\":0,\"cantidad\":1}]");
        servlet.doPost(req, resp);
        verify(resp).setStatus(400);
    }

    @Test
    void rojo_stockOSaldoInsuficiente_responde409() throws Exception {
        sesionDe(usuario(4, 11));
        cuerpo(CARRITO);
        when(dao.confirmarCompra(anyInt(), anyInt(), anyList()))
                .thenThrow(new SQLException("Saldo insuficiente", "45000"));
        servlet.doPost(req, resp);
        verify(resp).setStatus(409);
        assertTrue(respuesta().contains("Saldo insuficiente"));
    }

    @Test
    void rojo_errorDeBaseDeDatos_responde500() throws Exception {
        sesionDe(usuario(4, 11));
        cuerpo(CARRITO);
        when(dao.confirmarCompra(anyInt(), anyInt(), anyList()))
                .thenThrow(new SQLException("caída", "08001"));
        servlet.doPost(req, resp);
        verify(resp).setStatus(500);
    }
}
