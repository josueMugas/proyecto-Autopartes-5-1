package com.demografia.controller;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

import com.demografia.dao.FactoryDAO;
import com.demografia.modelo.Usuario;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.MockedStatic;

/**
 * Base común de los tests de servlets.
 * Reemplaza FactoryDAO por una versión simulada (sin base de datos) y
 * ofrece atajos para armar request, response y sesión falsos.
 *
 * Convención de los tests:
 *  - "verde": el servlet hace lo correcto con datos válidos.
 *  - "rojo":  el servlet debe rechazar/controlar una entrada inválida
 *             (sin lanzar excepciones ni responder 500).
 */
abstract class ServletTestBase {

    protected HttpServletRequest req;
    protected HttpServletResponse resp;
    protected HttpSession session;
    protected StringWriter salida;
    protected MockedStatic<FactoryDAO> fabrica;

    @BeforeEach
    void prepararBase() throws IOException {
        req = mock(HttpServletRequest.class);
        resp = mock(HttpServletResponse.class);
        session = mock(HttpSession.class);
        salida = new StringWriter();
        when(resp.getWriter()).thenReturn(new PrintWriter(salida, true));
        fabrica = mockStatic(FactoryDAO.class);
    }

    @AfterEach
    void cerrarBase() {
        fabrica.close();
    }

    protected void parametro(String nombre, String valor) {
        when(req.getParameter(nombre)).thenReturn(valor);
    }

    protected void cuerpo(String json) throws IOException {
        when(req.getReader()).thenReturn(new BufferedReader(new StringReader(json)));
    }

    protected void sinSesion() {
        when(req.getSession(false)).thenReturn(null);
    }

    protected void sesionDe(Usuario usuario) {
        when(req.getSession(false)).thenReturn(session);
        when(req.getSession(true)).thenReturn(session);
        when(session.getAttribute("usuarioLogueado")).thenReturn(usuario);
    }

    protected Usuario usuario(int idRol, int idCliente) {
        Usuario u = new Usuario("tester", "x", true, idRol);
        u.setIdUsuario(7);
        u.setIdCliente(idCliente);
        return u;
    }

    protected String respuesta() {
        return salida.toString();
    }
}
