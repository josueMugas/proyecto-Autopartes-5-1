package com.demografia.controller;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.demografia.dao.FactoryDAO;
import com.demografia.dao.IHojaDeRutaDAO;
import com.demografia.modelo.HojaDeRuta;
import java.util.Arrays;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class HojaDeRutaServletTest extends ServletTestBase {

    private IHojaDeRutaDAO dao;
    private HojaDeRutaServlet servlet;

    @BeforeEach
    void preparar() {
        dao = mock(IHojaDeRutaDAO.class);
        fabrica.when(FactoryDAO::getHojaDeRutaDAO).thenReturn(dao);
        servlet = new HojaDeRutaServlet();
    }

    // ---------- VERDE ----------

    @Test
    void verde_get_sinId_listaTodos() throws Exception {
        when(dao.listAll()).thenReturn(Arrays.asList(new HojaDeRuta(), new HojaDeRuta()));
        servlet.doGet(req, resp);
        verify(dao).listAll();
        assertTrue(respuesta().startsWith("["));
    }

    @Test
    void verde_get_conId_buscaPorId() throws Exception {
        parametro("id", "3");
        when(dao.listById(3)).thenReturn(new HojaDeRuta());
        servlet.doGet(req, resp);
        verify(dao).listById(3);
        assertTrue(respuesta().startsWith("{"));
    }

    @Test
    void verde_post_sinId_inserta() throws Exception {
        cuerpo("{}");
        when(dao.insert(any(HojaDeRuta.class))).thenReturn(true);
        servlet.doPost(req, resp);
        verify(dao).insert(any(HojaDeRuta.class));
        assertTrue(respuesta().contains("\"OK\""));
    }

    @Test
    void verde_post_conId_actualiza() throws Exception {
        cuerpo("{\"idHojaRuta\":5}");
        when(dao.update(any(HojaDeRuta.class))).thenReturn(true);
        servlet.doPost(req, resp);
        verify(dao).update(any(HojaDeRuta.class));
        verify(dao, never()).insert(any(HojaDeRuta.class));
        assertTrue(respuesta().contains("\"OK\""));
    }

    @Test
    void verde_post_siElDaoFalla_respondeError() throws Exception {
        cuerpo("{}");
        when(dao.insert(any(HojaDeRuta.class))).thenReturn(false);
        servlet.doPost(req, resp);
        assertTrue(respuesta().contains("\"ERROR\""));
    }

    @Test
    void verde_delete_borra() throws Exception {
        parametro("id", "4");
        when(dao.delete(4)).thenReturn(true);
        servlet.doDelete(req, resp);
        verify(dao).delete(4);
        assertTrue(respuesta().contains("\"OK\""));
    }

    // ---------- ROJO ----------

    @Test
    void rojo_get_idNoNumerico_responde400() throws Exception {
        parametro("id", "abc");
        servlet.doGet(req, resp);
        verify(resp).setStatus(400);
        verify(dao, never()).listById(anyInt());
    }

    @Test
    void rojo_post_cuerpoVacio_responde400() throws Exception {
        cuerpo("");
        servlet.doPost(req, resp);
        verify(resp).setStatus(400);
        verify(dao, never()).insert(any(HojaDeRuta.class));
        verify(dao, never()).update(any(HojaDeRuta.class));
    }

    @Test
    void rojo_post_jsonMalformado_responde400() throws Exception {
        cuerpo("{esto no es json");
        servlet.doPost(req, resp);
        verify(resp).setStatus(400);
        verify(dao, never()).insert(any(HojaDeRuta.class));
    }

    @Test
    void rojo_delete_sinId_responde400() throws Exception {
        servlet.doDelete(req, resp);
        verify(resp).setStatus(400);
        verify(dao, never()).delete(anyInt());
    }

    @Test
    void rojo_delete_idNoNumerico_responde400() throws Exception {
        parametro("id", "xyz");
        servlet.doDelete(req, resp);
        verify(resp).setStatus(400);
        verify(dao, never()).delete(anyInt());
    }
}
