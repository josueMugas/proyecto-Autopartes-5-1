package com.demografia.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.demografia.dao.FactoryDAO;
import com.demografia.dao.IClienteDAO;
import com.demografia.dao.IUsuarioDAO;
import com.demografia.modelo.Usuario;
import java.sql.SQLException;
import java.util.Collections;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mindrot.jbcrypt.BCrypt;

class AuthServletTest extends ServletTestBase {

    private IUsuarioDAO usuarioDAO;
    private IClienteDAO clienteDAO;
    private AuthServlet servlet;

    @BeforeEach
    void preparar() {
        usuarioDAO = mock(IUsuarioDAO.class);
        clienteDAO = mock(IClienteDAO.class);
        fabrica.when(FactoryDAO::getUsuarioDAO).thenReturn(usuarioDAO);
        fabrica.when(FactoryDAO::getClienteDAO).thenReturn(clienteDAO);
        servlet = new AuthServlet();
    }

    private Usuario usuarioConClave(String clave, int rol) {
        Usuario u = new Usuario("ana", clave, true, rol);
        u.setIdUsuario(1);
        return u;
    }

    // ================= LOGIN =================

    @Test
    void verde_login_claveEncriptada_iniciaSesion() throws Exception {
        sesionDe(null);
        Usuario u = usuarioConClave(BCrypt.hashpw("1234", BCrypt.gensalt(4)), 1);
        when(usuarioDAO.listAll()).thenReturn(Collections.singletonList(u));
        cuerpo("{\"action\":\"login\",\"nombreUsuario\":\"ANA\",\"clave\":\"1234\"}");
        servlet.doPost(req, resp);
        verify(session).setAttribute("usuarioLogueado", u);
        assertTrue(respuesta().contains("\"OK\""));
        assertTrue(respuesta().contains("\"idRol\":1"));
    }

    @Test
    void verde_login_claveEnTextoPlano_laMigraAHash() throws Exception {
        sesionDe(null);
        Usuario u = usuarioConClave("1234", 2);
        when(usuarioDAO.listAll()).thenReturn(Collections.singletonList(u));
        cuerpo("{\"action\":\"login\",\"nombreUsuario\":\"ana\",\"clave\":\"1234\"}");
        servlet.doPost(req, resp);
        verify(usuarioDAO).update(u);
        assertTrue(u.getClave().startsWith("$2"));
    }

    @Test
    void rojo_login_claveIncorrecta_responde401() throws Exception {
        Usuario u = usuarioConClave(BCrypt.hashpw("1234", BCrypt.gensalt(4)), 1);
        when(usuarioDAO.listAll()).thenReturn(Collections.singletonList(u));
        cuerpo("{\"action\":\"login\",\"nombreUsuario\":\"ana\",\"clave\":\"mala\"}");
        servlet.doPost(req, resp);
        verify(resp).setStatus(401);
        verify(req, never()).getSession(true);
    }

    @Test
    void rojo_login_usuarioInexistente_responde401() throws Exception {
        when(usuarioDAO.listAll()).thenReturn(Collections.emptyList());
        cuerpo("{\"action\":\"login\",\"nombreUsuario\":\"nadie\",\"clave\":\"1234\"}");
        servlet.doPost(req, resp);
        verify(resp).setStatus(401);
    }

    @Test
    void rojo_login_sinCredenciales_responde400() throws Exception {
        cuerpo("{\"action\":\"login\"}");
        servlet.doPost(req, resp);
        verify(resp).setStatus(400);
        verify(usuarioDAO, never()).listAll();
    }

    @Test
    void rojo_login_claveVacia_responde400() throws Exception {
        cuerpo("{\"action\":\"login\",\"nombreUsuario\":\"ana\",\"clave\":\"\"}");
        servlet.doPost(req, resp);
        verify(resp).setStatus(400);
    }

    @Test
    void rojo_login_baseCaida_responde500() throws Exception {
        when(usuarioDAO.listAll()).thenThrow(new IllegalStateException("sin base"));
        cuerpo("{\"action\":\"login\",\"nombreUsuario\":\"ana\",\"clave\":\"1234\"}");
        servlet.doPost(req, resp);
        verify(resp).setStatus(500);
    }

    // ================= ACCIONES GENERALES =================

    @Test
    void rojo_accionInvalida_responde400() throws Exception {
        cuerpo("{\"action\":\"hackear\"}");
        servlet.doPost(req, resp);
        verify(resp).setStatus(400);
    }

    @Test
    void rojo_sinAccion_responde400() throws Exception {
        cuerpo("");
        servlet.doPost(req, resp);
        verify(resp).setStatus(400);
    }

    @Test
    void rojo_jsonMalformado_responde400() throws Exception {
        cuerpo("{no es json");
        servlet.doPost(req, resp);
        verify(resp).setStatus(400);
    }

    @Test
    void rojo_cuerpoQueNoEsObjeto_responde400() throws Exception {
        cuerpo("[1,2,3]");
        servlet.doPost(req, resp);
        verify(resp).setStatus(400);
    }

    @Test
    void verde_logout_invalidaLaSesion() throws Exception {
        sesionDe(null);
        cuerpo("{\"action\":\"logout\"}");
        servlet.doPost(req, resp);
        verify(session).invalidate();
        assertTrue(respuesta().contains("\"OK\""));
    }

    @Test
    void verde_logout_sinSesion_noFalla() throws Exception {
        sinSesion();
        cuerpo("{\"action\":\"logout\"}");
        servlet.doPost(req, resp);
        assertTrue(respuesta().contains("\"OK\""));
    }

    // ================= REGISTRO =================

    @Test
    void verde_register_proveedor_insertaUsuario() throws Exception {
        when(usuarioDAO.insert(any(Usuario.class))).thenReturn(true);
        cuerpo("{\"action\":\"register\",\"nombreUsuario\":\"nuevo\",\"clave\":\"abcd\",\"idRol\":3}");
        servlet.doPost(req, resp);
        verify(usuarioDAO).insert(any(Usuario.class));
        assertTrue(respuesta().contains("\"OK\""));
    }

    @Test
    void verde_register_guardaLaClaveEncriptada() throws Exception {
        when(usuarioDAO.insert(any(Usuario.class))).thenAnswer(inv -> {
            Usuario u = inv.getArgument(0);
            assertTrue(BCrypt.checkpw("abcd", u.getClave()));
            return true;
        });
        cuerpo("{\"action\":\"register\",\"nombreUsuario\":\"nuevo\",\"clave\":\"abcd\",\"idRol\":2}");
        servlet.doPost(req, resp);
        verify(usuarioDAO).insert(any(Usuario.class));
    }

    @Test
    void verde_register_cliente_insertaClienteYUsuario() throws Exception {
        when(usuarioDAO.insertCliente(any(Usuario.class), eq("Ana"), eq("Paz"), any(), any()))
                .thenReturn(true);
        cuerpo("{\"action\":\"register\",\"nombreUsuario\":\"ana\",\"clave\":\"abcd\",\"idRol\":4,"
                + "\"nombre\":\"Ana\",\"apellido\":\"Paz\"}");
        servlet.doPost(req, resp);
        verify(usuarioDAO).insertCliente(any(Usuario.class), eq("Ana"), eq("Paz"), any(), any());
        assertTrue(respuesta().contains("\"OK\""));
    }

    @Test
    void rojo_register_usuarioDuplicado_responde409() throws Exception {
        when(usuarioDAO.insert(any(Usuario.class))).thenReturn(false);
        cuerpo("{\"action\":\"register\",\"nombreUsuario\":\"ana\",\"clave\":\"abcd\",\"idRol\":3}");
        servlet.doPost(req, resp);
        verify(resp).setStatus(409);
    }

    @Test
    void rojo_register_rolAdministrador_noSePuedeRegistrar() throws Exception {
        cuerpo("{\"action\":\"register\",\"nombreUsuario\":\"ana\",\"clave\":\"abcd\",\"idRol\":1}");
        servlet.doPost(req, resp);
        verify(resp).setStatus(400);
        verify(usuarioDAO, never()).insert(any(Usuario.class));
    }

    @Test
    void rojo_register_sinRol_responde400() throws Exception {
        cuerpo("{\"action\":\"register\",\"nombreUsuario\":\"ana\",\"clave\":\"abcd\"}");
        servlet.doPost(req, resp);
        verify(resp).setStatus(400);
    }

    @Test
    void rojo_register_claveCorta_responde400() throws Exception {
        cuerpo("{\"action\":\"register\",\"nombreUsuario\":\"ana\",\"clave\":\"123\",\"idRol\":3}");
        servlet.doPost(req, resp);
        verify(resp).setStatus(400);
        verify(usuarioDAO, never()).insert(any(Usuario.class));
    }

    @Test
    void rojo_register_claveMasDe72Bytes_responde400() throws Exception {
        String larga = "a".repeat(73);
        cuerpo("{\"action\":\"register\",\"nombreUsuario\":\"ana\",\"clave\":\"" + larga + "\",\"idRol\":3}");
        servlet.doPost(req, resp);
        verify(resp).setStatus(400);
    }

    @Test
    void rojo_register_usuarioMasDe50Caracteres_responde400() throws Exception {
        String largo = "u".repeat(51);
        cuerpo("{\"action\":\"register\",\"nombreUsuario\":\"" + largo + "\",\"clave\":\"abcd\",\"idRol\":3}");
        servlet.doPost(req, resp);
        verify(resp).setStatus(400);
    }

    @Test
    void rojo_register_clienteSinNombre_responde400() throws Exception {
        cuerpo("{\"action\":\"register\",\"nombreUsuario\":\"ana\",\"clave\":\"abcd\",\"idRol\":4}");
        servlet.doPost(req, resp);
        verify(resp).setStatus(400);
        verify(usuarioDAO, never()).insertCliente(any(), anyString(), anyString(), any(), any());
    }

    // ================= CARGAR SALDO =================

    @Test
    void verde_cargarSaldo_cliente_actualizaSaldo() throws Exception {
        sesionDe(usuario(4, 11));
        when(clienteDAO.cargarSaldo(11, 500.0)).thenReturn(1500.0);
        cuerpo("{\"action\":\"cargarSaldo\",\"monto\":500}");
        servlet.doPost(req, resp);
        verify(clienteDAO).cargarSaldo(11, 500.0);
        assertTrue(respuesta().contains("\"saldo\":1500.0"));
    }

    @Test
    void rojo_cargarSaldo_sinSesion_responde403() throws Exception {
        sinSesion();
        cuerpo("{\"action\":\"cargarSaldo\",\"monto\":500}");
        servlet.doPost(req, resp);
        verify(resp).setStatus(403);
        verify(clienteDAO, never()).cargarSaldo(anyInt(), anyDouble());
    }

    @Test
    void rojo_cargarSaldo_noEsCliente_responde403() throws Exception {
        sesionDe(usuario(1, 0));
        cuerpo("{\"action\":\"cargarSaldo\",\"monto\":500}");
        servlet.doPost(req, resp);
        verify(resp).setStatus(403);
    }

    @Test
    void rojo_cargarSaldo_montoNegativo_responde400() throws Exception {
        sesionDe(usuario(4, 11));
        cuerpo("{\"action\":\"cargarSaldo\",\"monto\":-10}");
        servlet.doPost(req, resp);
        verify(resp).setStatus(400);
        verify(clienteDAO, never()).cargarSaldo(anyInt(), anyDouble());
    }

    @Test
    void rojo_cargarSaldo_montoCero_responde400() throws Exception {
        sesionDe(usuario(4, 11));
        cuerpo("{\"action\":\"cargarSaldo\",\"monto\":0}");
        servlet.doPost(req, resp);
        verify(resp).setStatus(400);
    }

    @Test
    void rojo_cargarSaldo_sinMonto_responde400() throws Exception {
        sesionDe(usuario(4, 11));
        cuerpo("{\"action\":\"cargarSaldo\"}");
        servlet.doPost(req, resp);
        verify(resp).setStatus(400);
    }

    @Test
    void rojo_cargarSaldo_errorSql_responde500() throws Exception {
        sesionDe(usuario(4, 11));
        when(clienteDAO.cargarSaldo(anyInt(), anyDouble())).thenThrow(new SQLException("boom"));
        cuerpo("{\"action\":\"cargarSaldo\",\"monto\":50}");
        servlet.doPost(req, resp);
        verify(resp).setStatus(500);
    }

    // ================= GET (estado de sesión) =================

    @Test
    void verde_get_sinSesion_noAutenticado() throws Exception {
        sinSesion();
        servlet.doGet(req, resp);
        assertTrue(respuesta().contains("\"autenticado\":false"));
    }

    @Test
    void verde_get_conSesion_devuelveUsuarioYSaldo() throws Exception {
        sesionDe(usuario(4, 11));
        when(clienteDAO.obtenerSaldo(11)).thenReturn(250.0);
        servlet.doGet(req, resp);
        assertTrue(respuesta().contains("\"autenticado\":true"));
        assertTrue(respuesta().contains("\"saldo\":250.0"));
    }

    @Test
    void verde_get_adminSinCliente_noConsultaSaldo() throws Exception {
        sesionDe(usuario(1, 0));
        servlet.doGet(req, resp);
        verify(clienteDAO, never()).obtenerSaldo(anyInt());
        assertEquals(true, respuesta().contains("\"autenticado\":true"));
    }

    @Test
    void rojo_get_errorSqlAlLeerSaldo_responde500() throws Exception {
        sesionDe(usuario(4, 11));
        when(clienteDAO.obtenerSaldo(11)).thenThrow(new SQLException("boom"));
        servlet.doGet(req, resp);
        verify(resp).setStatus(500);
    }
}
