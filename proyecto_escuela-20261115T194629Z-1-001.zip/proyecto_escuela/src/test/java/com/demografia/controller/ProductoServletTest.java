package com.demografia.controller;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.demografia.dao.FactoryDAO;
import com.demografia.dao.IProductoDAO;
import com.demografia.modelo.Producto;
import java.util.Arrays;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ProductoServletTest extends ServletTestBase {

    private static final String PRODUCTO_VALIDO =
            "{\"codigo\":\"P-1\",\"nombre\":\"Mesa\",\"precioVenta\":1500.50}";

    private IProductoDAO dao;
    private ProductoServlet servlet;

    @BeforeEach
    void preparar() {
        dao = mock(IProductoDAO.class);
        fabrica.when(FactoryDAO::getProductoDAO).thenReturn(dao);
        servlet = new ProductoServlet();
    }

    // ---------- VERDE ----------

    @Test
    void verde_get_sinId_listaTodosSinSesion() throws Exception {
        when(dao.listAll()).thenReturn(Arrays.asList(new Producto(), new Producto()));
        servlet.doGet(req, resp);
        verify(dao).listAll();
        assertTrue(respuesta().startsWith("["));
    }

    @Test
    void verde_get_conId_buscaPorId() throws Exception {
        parametro("id", "3");
        when(dao.listById(3)).thenReturn(new Producto());
        servlet.doGet(req, resp);
        verify(dao).listById(3);
    }

    @Test
    void verde_get_masVendidos_siEsAdmin() throws Exception {
        parametro("accion", "masVendidos");
        sesionDe(usuario(1, 0));
        when(dao.listTopSold()).thenReturn(Arrays.asList(new Producto()));
        servlet.doGet(req, resp);
        verify(dao).listTopSold();
    }

    @Test
    void verde_post_admin_insertaProductoNuevo() throws Exception {
        sesionDe(usuario(1, 0));
        cuerpo(PRODUCTO_VALIDO);
        when(dao.insert(any(Producto.class))).thenReturn(true);
        servlet.doPost(req, resp);
        verify(dao).insert(any(Producto.class));
        assertTrue(respuesta().contains("\"OK\""));
    }

    @Test
    void verde_post_admin_actualizaProductoExistente() throws Exception {
        sesionDe(usuario(1, 0));
        cuerpo("{\"idProducto\":9,\"codigo\":\"P-1\",\"nombre\":\"Mesa\",\"precioVenta\":10}");
        when(dao.update(any(Producto.class))).thenReturn(true);
        servlet.doPost(req, resp);
        verify(dao).update(any(Producto.class));
        verify(dao, never()).insert(any(Producto.class));
    }

    @Test
    void verde_delete_admin_borra() throws Exception {
        sesionDe(usuario(1, 0));
        parametro("id", "4");
        when(dao.delete(4)).thenReturn(true);
        servlet.doDelete(req, resp);
        verify(dao).delete(4);
        assertTrue(respuesta().contains("\"OK\""));
    }

    @Test
    void verde_delete_admin_fisico() throws Exception {
        sesionDe(usuario(1, 0));
        parametro("id", "4");
        parametro("fisico", "true");
        when(dao.deleteFisico(4)).thenReturn(true);
        servlet.doDelete(req, resp);
        verify(dao).deleteFisico(4);
        verify(dao, never()).delete(anyInt());
    }

    // ---------- ROJO ----------

    @Test
    void rojo_get_masVendidos_sinSesion_responde403() throws Exception {
        parametro("accion", "masVendidos");
        sinSesion();
        servlet.doGet(req, resp);
        verify(resp).sendError(eq(403), anyString());
        verify(dao, never()).listTopSold();
    }

    @Test
    void rojo_get_masVendidos_siEsCliente_responde403() throws Exception {
        parametro("accion", "masVendidos");
        sesionDe(usuario(4, 1));
        servlet.doGet(req, resp);
        verify(resp).sendError(eq(403), anyString());
    }

    @Test
    void rojo_post_sinSesion_responde403() throws Exception {
        sinSesion();
        cuerpo(PRODUCTO_VALIDO);
        servlet.doPost(req, resp);
        verify(resp).sendError(eq(403), anyString());
        verify(dao, never()).insert(any(Producto.class));
    }

    @Test
    void rojo_post_clienteNoPuedeModificar_responde403() throws Exception {
        sesionDe(usuario(4, 1));
        cuerpo(PRODUCTO_VALIDO);
        servlet.doPost(req, resp);
        verify(resp).sendError(eq(403), anyString());
        verify(dao, never()).insert(any(Producto.class));
    }

    @Test
    void rojo_post_admin_sinPrecio_responde400() throws Exception {
        sesionDe(usuario(1, 0));
        cuerpo("{\"codigo\":\"P-1\",\"nombre\":\"Mesa\"}");
        servlet.doPost(req, resp);
        verify(resp).sendError(eq(400), anyString());
        verify(dao, never()).insert(any(Producto.class));
    }

    @Test
    void rojo_post_admin_precioNegativo_responde400() throws Exception {
        sesionDe(usuario(1, 0));
        cuerpo("{\"codigo\":\"P-1\",\"nombre\":\"Mesa\",\"precioVenta\":-5}");
        servlet.doPost(req, resp);
        verify(resp).sendError(eq(400), anyString());
    }

    @Test
    void rojo_post_admin_sinCodigo_responde400() throws Exception {
        sesionDe(usuario(1, 0));
        cuerpo("{\"nombre\":\"Mesa\",\"precioVenta\":10}");
        servlet.doPost(req, resp);
        verify(resp).sendError(eq(400), anyString());
    }

    @Test
    void rojo_post_admin_cuerpoVacio_responde400() throws Exception {
        sesionDe(usuario(1, 0));
        cuerpo("");
        servlet.doPost(req, resp);
        verify(resp).sendError(eq(400), anyString());
    }

    @Test
    void rojo_post_admin_jsonMalformado_responde400() throws Exception {
        sesionDe(usuario(1, 0));
        cuerpo("{no es json");
        servlet.doPost(req, resp);
        verify(resp).sendError(eq(400), anyString());
    }

    @Test
    void rojo_delete_sinSesion_responde403() throws Exception {
        sinSesion();
        parametro("id", "4");
        servlet.doDelete(req, resp);
        verify(resp).sendError(eq(403), anyString());
        verify(dao, never()).delete(anyInt());
    }

    @Test
    void rojo_delete_admin_sinId_responde400() throws Exception {
        sesionDe(usuario(1, 0));
        servlet.doDelete(req, resp);
        verify(resp).setStatus(400);
        verify(dao, never()).delete(anyInt());
    }

    @Test
    void rojo_get_idNoNumerico_responde400() throws Exception {
        parametro("id", "abc");
        servlet.doGet(req, resp);
        verify(resp).setStatus(400);
        verify(dao, never()).listById(anyInt());
    }
}
