package com.demografia.controller;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class HomeServletTest extends ServletTestBase {

    private final HomeServlet servlet = new HomeServlet();

    @Test
    void verde_get_respondeElSaludo() throws Exception {
        servlet.doGet(req, resp);
        assertTrue(respuesta().contains("Hola mundo desde HomeServlet"));
    }
}
