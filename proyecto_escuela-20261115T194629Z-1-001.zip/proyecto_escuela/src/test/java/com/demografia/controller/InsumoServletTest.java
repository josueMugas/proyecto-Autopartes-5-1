package com.demografia.controller;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.demografia.dao.FactoryDAO;
import com.demografia.dao.IInsumoDAO;
import com.demografia.modelo.Insumo;
import java.math.BigDecimal;
import java.util.Arrays;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class InsumoServletTest extends ServletTestBase {

    private IInsumoDAO dao;
    private InsumoServlet servlet;

    @BeforeEach
    void preparar() {
        dao = mock(IInsumoDAO.class);
        fabrica.when(FactoryDAO::getInsumoDAO).thenReturn(dao);
        servlet = new InsumoServlet();
    }

    // ---------- VERDE ----------

    @Test
    void verde_get_sinId_listaTodos() throws Exception {
        when(dao.listAll()).thenReturn(Arrays.asList(new Insumo(), new Insumo()));
        servlet.doGet(req, resp);
        verify(dao).listAll();
        assertTrue(respuesta().startsWith("["));
    }

    @Test
    void verde_get_conId_buscaPorId() throws Exception {
        parametro("id", "3");
        when(dao.listById(3)).thenReturn(new Insumo());
        servlet.doGet(req, resp);
        verify(dao).listById(3);
        assertTrue(respuesta().startsWith("{"));
    }

    @Test
    void verde_post_sinId_inserta() throws Exception {
        cuerpo("{}");
        when(dao.insert(any(Insumo.class))).thenReturn(true);
        servlet.doPost(req, resp);
        verify(dao).insert(any(Insumo.class));
        assertTrue(respuesta().contains("\"OK\""));
    }

    @Test
    void verde_post_conId_actualiza() throws Exception {
        cuerpo("{\"idInsumo\":5}");
        when(dao.update(any(Insumo.class))).thenReturn(true);
        servlet.doPost(req, resp);
        verify(dao).update(any(Insumo.class));
        verify(dao, never()).insert(any(Insumo.class));
        assertTrue(respuesta().contains("\"OK\""));
    }

    @Test
    void verde_post_siElDaoFalla_respondeError() throws Exception {
        cuerpo("{}");
        when(dao.insert(any(Insumo.class))).thenReturn(false);
        servlet.doPost(req, resp);
        assertTrue(respuesta().contains("\"ERROR\""));
    }

    @Test
    void verde_delete_borra() throws Exception {
        parametro("id", "4");
        when(dao.delete(4)).thenReturn(true);
        servlet.doDelete(req, resp);
        verify(dao).delete(4);
        assertTrue(respuesta().contains("\"OK\""));
    }

    // ---------- ROJO ----------

    @Test
    void rojo_get_idNoNumerico_responde400() throws Exception {
        parametro("id", "abc");
        servlet.doGet(req, resp);
        verify(resp).setStatus(400);
        verify(dao, never()).listById(anyInt());
    }

    @Test
    void rojo_post_cuerpoVacio_responde400() throws Exception {
        cuerpo("");
        servlet.doPost(req, resp);
        verify(resp).sendError(eq(400), anyString());
        verify(dao, never()).insert(any(Insumo.class));
        verify(dao, never()).update(any(Insumo.class));
    }

    @Test
    void rojo_post_jsonMalformado_responde400() throws Exception {
        cuerpo("{esto no es json");
        servlet.doPost(req, resp);
        verify(resp).sendError(eq(400), anyString());
        verify(dao, never()).insert(any(Insumo.class));
    }

    @Test
    void rojo_delete_sinId_responde400() throws Exception {
        servlet.doDelete(req, resp);
        verify(resp).setStatus(400);
        verify(dao, never()).delete(anyInt());
    }

    @Test
    void rojo_delete_idNoNumerico_responde400() throws Exception {
        parametro("id", "xyz");
        servlet.doDelete(req, resp);
        verify(resp).setStatus(400);
        verify(dao, never()).delete(anyInt());
    }

    // ---------- Reposición de stock ----------

    @Test
    void verde_post_reponer_sumaStock() throws Exception {
        parametro("accion", "reponer");
        cuerpo("{\"idInsumo\":2,\"stockActual\":10}");
        when(dao.reponerStock(eq(2), any(BigDecimal.class))).thenReturn(true);
        servlet.doPost(req, resp);
        verify(dao).reponerStock(eq(2), any(BigDecimal.class));
        assertTrue(respuesta().contains("\"OK\""));
    }

    @Test
    void rojo_post_reponer_cantidadNegativa_responde400() throws Exception {
        parametro("accion", "reponer");
        cuerpo("{\"idInsumo\":2,\"stockActual\":-5}");
        servlet.doPost(req, resp);
        verify(resp).sendError(eq(400), anyString());
        verify(dao, never()).reponerStock(anyInt(), any(BigDecimal.class));
    }

    @Test
    void rojo_post_reponer_sinInsumo_responde400() throws Exception {
        parametro("accion", "reponer");
        cuerpo("{\"stockActual\":5}");
        servlet.doPost(req, resp);
        verify(resp).sendError(eq(400), anyString());
        verify(dao, never()).reponerStock(anyInt(), any(BigDecimal.class));
    }

    @Test
    void verde_delete_fisico_usaDeleteFisico() throws Exception {
        parametro("id", "4");
        parametro("fisico", "true");
        when(dao.deleteFisico(4)).thenReturn(true);
        servlet.doDelete(req, resp);
        verify(dao).deleteFisico(4);
        verify(dao, never()).delete(anyInt());
    }
}
