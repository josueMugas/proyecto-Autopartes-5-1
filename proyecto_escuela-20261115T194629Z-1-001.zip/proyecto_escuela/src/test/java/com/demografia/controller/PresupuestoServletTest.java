package com.demografia.controller;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.demografia.dao.FactoryDAO;
import com.demografia.dao.IPresupuestoDAO;
import com.demografia.modelo.Presupuesto;
import java.util.Arrays;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PresupuestoServletTest extends ServletTestBase {

    private IPresupuestoDAO dao;
    private PresupuestoServlet servlet;

    @BeforeEach
    void preparar() {
        dao = mock(IPresupuestoDAO.class);
        fabrica.when(FactoryDAO::getPresupuestoDAO).thenReturn(dao);
        servlet = new PresupuestoServlet();
    }

    // ---------- VERDE ----------

    @Test
    void verde_get_sinId_listaTodos() throws Exception {
        when(dao.listAll()).thenReturn(Arrays.asList(new Presupuesto(), new Presupuesto()));
        servlet.doGet(req, resp);
        verify(dao).listAll();
        assertTrue(respuesta().startsWith("["));
    }

    @Test
    void verde_get_conId_buscaPorId() throws Exception {
        parametro("id", "3");
        when(dao.listById(3)).thenReturn(new Presupuesto());
        servlet.doGet(req, resp);
        verify(dao).listById(3);
    }

    // ---------- ROJO ----------

    @Test
    void rojo_post_noPermitido_responde405() throws Exception {
        servlet.doPost(req, resp);
        verify(resp).setStatus(405);
        verify(dao, never()).insert(any(Presupuesto.class));
    }

    @Test
    void rojo_delete_noPermitido_responde405() throws Exception {
        parametro("id", "3");
        servlet.doDelete(req, resp);
        verify(resp).setStatus(405);
        verify(dao, never()).delete(anyInt());
    }

    @Test
    void rojo_get_idNoNumerico_responde400() throws Exception {
        parametro("id", "abc");
        servlet.doGet(req, resp);
        verify(resp).setStatus(400);
        verify(dao, never()).listById(anyInt());
    }
}
