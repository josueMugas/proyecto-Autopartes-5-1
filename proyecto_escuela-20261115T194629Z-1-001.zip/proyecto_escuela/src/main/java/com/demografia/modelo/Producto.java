package com.demografia.modelo;

import java.math.BigDecimal;

public class Producto {
    private int idProducto;
    private String codigo;
    private String nombre;
    private String planoTecnicoUrl;
    private int stockDisponible;
    private BigDecimal precioVenta = BigDecimal.ZERO;
    private long totalVendido;

    public Producto() {}

    public Producto(String codigo, String nombre, String planoTecnicoUrl) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.planoTecnicoUrl = planoTecnicoUrl;
    }

    public int getIdProducto() { return idProducto; }
    public void setIdProducto(int idProducto) { this.idProducto = idProducto; }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getPlanoTecnicoUrl() { return planoTecnicoUrl; }
    public void setPlanoTecnicoUrl(String planoTecnicoUrl) { this.planoTecnicoUrl = planoTecnicoUrl; }

    public int getStockDisponible() { return stockDisponible; }
    public void setStockDisponible(int stockDisponible) { this.stockDisponible = stockDisponible; }

    public BigDecimal getPrecioVenta() { return precioVenta; }
    public void setPrecioVenta(BigDecimal precioVenta) {
        this.precioVenta = precioVenta == null ? BigDecimal.ZERO : precioVenta;
    }

    public long getTotalVendido() { return totalVendido; }
    public void setTotalVendido(long totalVendido) { this.totalVendido = totalVendido; }}
