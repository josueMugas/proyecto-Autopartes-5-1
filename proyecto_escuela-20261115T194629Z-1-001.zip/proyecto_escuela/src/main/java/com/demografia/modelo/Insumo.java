package com.demografia.modelo;

import java.math.BigDecimal;

public class Insumo {
    private int idInsumo;
    private String codigo;
    private String nombre;
    private String tipoMaterial;
    private BigDecimal stockActual = BigDecimal.ZERO;
    private BigDecimal stockMinimo = BigDecimal.ZERO;
    private String unidadMedida;

    public Insumo() {}

    public Insumo(String codigo, String nombre, String tipoMaterial, 
                  BigDecimal stockActual, BigDecimal stockMinimo, String unidadMedida) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.tipoMaterial = tipoMaterial;
        this.stockActual = stockActual;
        this.stockMinimo = stockMinimo;
        this.unidadMedida = unidadMedida;
    }

    public int getIdInsumo() { return idInsumo; }
    public void setIdInsumo(int idInsumo) { this.idInsumo = idInsumo; }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getTipoMaterial() { return tipoMaterial; }
    public void setTipoMaterial(String tipoMaterial) { this.tipoMaterial = tipoMaterial; }

    public BigDecimal getStockActual() { return stockActual; }
    public void setStockActual(BigDecimal stockActual) {
        this.stockActual = stockActual == null ? BigDecimal.ZERO : stockActual;
    }

    public BigDecimal getStockMinimo() { return stockMinimo; }
    public void setStockMinimo(BigDecimal stockMinimo) {
        this.stockMinimo = stockMinimo == null ? BigDecimal.ZERO : stockMinimo;
    }

    public String getUnidadMedida() { return unidadMedida; }
    public void setUnidadMedida(String unidadMedida) { this.unidadMedida = unidadMedida; }
}