package com.demografia.modelo;

import java.math.BigDecimal;

public class CompraResultado {
    private final int idPresupuesto;
    private final BigDecimal total;
    private final BigDecimal saldoRestante;

    public CompraResultado(int idPresupuesto, BigDecimal total, BigDecimal saldoRestante) {
        this.idPresupuesto = idPresupuesto;
        this.total = total;
        this.saldoRestante = saldoRestante;
    }

    public int getIdPresupuesto() { return idPresupuesto; }
    public BigDecimal getTotal() { return total; }
    public BigDecimal getSaldoRestante() { return saldoRestante; }
}
