package com.demografia.controller;

import com.demografia.dao.FactoryDAO;
import com.demografia.dao.IClienteDAO;
import com.demografia.dao.IUsuarioDAO;
import com.demografia.modelo.Usuario;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import org.mindrot.jbcrypt.BCrypt;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;

@WebServlet("/AuthServlet")
public class AuthServlet extends HttpServlet {

    private final IUsuarioDAO usuarioDAO = FactoryDAO.getUsuarioDAO();
    private final IClienteDAO clienteDAO = FactoryDAO.getClienteDAO();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");

        JsonObject datos;
        try {
            datos = leerJson(req);
        } catch (JsonParseException | IllegalStateException e) {
            escribirError(resp, HttpServletResponse.SC_BAD_REQUEST, "El cuerpo de la solicitud no es válido");
            return;
        }

        String action = valor(datos, "action", req.getParameter("action"));
        String username = valor(datos, "nombreUsuario", req.getParameter("nombreUsuario"));
        String password = valor(datos, "clave", req.getParameter("clave"));
        String nombre = valor(datos, "nombre", req.getParameter("nombre"));
        String apellido = valor(datos, "apellido", req.getParameter("apellido"));
        String email = valor(datos, "email", req.getParameter("email"));
        String telefono = valor(datos, "telefono", req.getParameter("telefono"));

        if ("login".equals(action)) {
            iniciarSesion(username, password, req, resp);
        } else if ("register".equals(action)) {
            registrar(username, password, nombre, apellido, email, telefono, datos, req, resp);
        } else if ("cargarSaldo".equals(action)) {
            cargarSaldo(datos, req, resp);
        } else if ("logout".equals(action)) {
            HttpSession session = req.getSession(false);
            if (session != null) {
                session.invalidate();
            }
            escribirEstado(resp, HttpServletResponse.SC_OK, "OK");
        } else {
            escribirError(resp, HttpServletResponse.SC_BAD_REQUEST, "Acción no válida");
        }
    }

    private void iniciarSesion(String username, String password, HttpServletRequest req,
                                HttpServletResponse resp) throws IOException {
        if (username == null || username.trim().isEmpty() || password == null || password.isEmpty()) {
            escribirError(resp, HttpServletResponse.SC_BAD_REQUEST, "Ingresá usuario y contraseña");
            return;
        }

        try {
            Usuario usuario = usuarioDAO.listAll().stream()
                    .filter(u -> u.getNombreUsuario() != null
                            && u.getNombreUsuario().equalsIgnoreCase(username.trim()))
                    .filter(u -> validarClave(u, password))
                    .findFirst().orElse(null);
            if (usuario == null) {
                escribirError(resp, HttpServletResponse.SC_UNAUTHORIZED, "Usuario o contraseña incorrectos");
                return;
            }

            req.getSession(true).setAttribute("usuarioLogueado", usuario);
            JsonObject respuesta = new JsonObject();
            respuesta.addProperty("status", "OK");
            respuesta.addProperty("idRol", usuario.getIdRol());
            resp.getWriter().write(respuesta.toString());
        } catch (IllegalStateException e) {
            e.printStackTrace();
            escribirError(resp, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "No se pudo consultar la base de datos");
        }
    }

    private boolean validarClave(Usuario usuario, String password) {
        String claveGuardada = usuario.getClave();
        if (claveGuardada == null) {
            return false;
        }

        if (claveGuardada.startsWith("$2a$") || claveGuardada.startsWith("$2b$")
                || claveGuardada.startsWith("$2y$")) {
            try {
                return BCrypt.checkpw(password, claveGuardada);
            } catch (IllegalArgumentException e) {
                return false;
            }
        }

        if (!claveGuardada.equals(password)) {
            return false;
        }
        usuario.setClave(BCrypt.hashpw(password, BCrypt.gensalt()));
        usuarioDAO.update(usuario);
        return true;
    }

    private void registrar(String username, String password, String nombre, String apellido,
                           String email, String telefono, JsonObject datos, HttpServletRequest req,
                           HttpServletResponse resp) throws IOException {
        int idRol;
        try {
            idRol = entero(datos, "idRol", req.getParameter("idRol"));
        } catch (NumberFormatException e) {
            escribirError(resp, HttpServletResponse.SC_BAD_REQUEST, "Seleccioná un rol válido");
            return;
        }

        if (username == null || username.trim().isEmpty() || username.trim().length() > 50
                || password == null || password.length() < 4
                || password.getBytes(StandardCharsets.UTF_8).length > 72) {
            escribirError(resp, HttpServletResponse.SC_BAD_REQUEST,
                    "Ingresá un usuario de hasta 50 caracteres y una contraseña de entre 4 y 72 bytes");
            return;
        }
        if (idRol != 2 && idRol != 3 && idRol != 4) {
            escribirError(resp, HttpServletResponse.SC_BAD_REQUEST, "El rol seleccionado no se puede registrar");
            return;
        }
        if (idRol == 4 && (nombre == null || nombre.trim().isEmpty()
                || apellido == null || apellido.trim().isEmpty())) {
            escribirError(resp, HttpServletResponse.SC_BAD_REQUEST, "Completá nombre y apellido del cliente");
            return;
        }

        Usuario nuevo = new Usuario();
        nuevo.setNombreUsuario(username.trim());
        nuevo.setClave(BCrypt.hashpw(password, BCrypt.gensalt()));
        nuevo.setIdRol(idRol);
        nuevo.setActivo(true);

        boolean ok;
        try {
            ok = idRol == 4
                    ? usuarioDAO.insertCliente(nuevo, nombre.trim(), apellido.trim(), limpiar(email),
                            limpiar(telefono))
                    : usuarioDAO.insert(nuevo);
        } catch (IllegalStateException e) {
            log("No se pudo guardar el registro de usuario", e);
            escribirError(resp, HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "No se pudo guardar el usuario en la base de datos. Verificá que se haya aplicado "
                            + "migracion_compras_stock.sql y revisá el registro del servidor.");
            return;
        }
        if (!ok) {
            escribirError(resp, HttpServletResponse.SC_CONFLICT,
                    "Ese nombre de usuario ya está registrado. Elegí otro.");
            return;
        }
        escribirEstado(resp, HttpServletResponse.SC_OK, "OK");
    }

    private void cargarSaldo(JsonObject datos, HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession session = req.getSession(false);
        Usuario usuario = session == null ? null : (Usuario) session.getAttribute("usuarioLogueado");
        if (usuario == null || usuario.getIdRol() != 4 || usuario.getIdCliente() < 1) {
            escribirError(resp, HttpServletResponse.SC_FORBIDDEN, "La cuenta no tiene un cliente asociado");
            return;
        }

        double monto;
        try {
            monto = decimal(datos, "monto", req.getParameter("monto"));
        } catch (NumberFormatException e) {
            escribirError(resp, HttpServletResponse.SC_BAD_REQUEST, "Ingresá un monto mayor a cero");
            return;
        }
        if (!Double.isFinite(monto) || monto <= 0) {
            escribirError(resp, HttpServletResponse.SC_BAD_REQUEST, "Ingresá un monto mayor a cero");
            return;
        }

        try {
            JsonObject respuesta = new JsonObject();
            respuesta.addProperty("status", "OK");
            respuesta.addProperty("saldo", clienteDAO.cargarSaldo(usuario.getIdCliente(), monto));
            resp.getWriter().write(respuesta.toString());
        } catch (SQLException e) {
            e.printStackTrace();
            escribirError(resp, HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "No se pudo actualizar el saldo en la base de datos");
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");

        HttpSession session = req.getSession(false);
        Usuario usuario = session == null ? null : (Usuario) session.getAttribute("usuarioLogueado");
        if (usuario == null) {
            JsonObject respuesta = new JsonObject();
            respuesta.addProperty("autenticado", false);
            resp.getWriter().write(respuesta.toString());
            return;
        }

        JsonObject datosUsuario = new JsonObject();
        datosUsuario.addProperty("nombreUsuario", usuario.getNombreUsuario());
        datosUsuario.addProperty("idRol", usuario.getIdRol());
        datosUsuario.addProperty("idCliente", usuario.getIdCliente());

        JsonObject respuesta = new JsonObject();
        respuesta.addProperty("autenticado", true);
        respuesta.add("usuario", datosUsuario);
        if (usuario.getIdCliente() > 0) {
            try {
                respuesta.addProperty("saldo", clienteDAO.obtenerSaldo(usuario.getIdCliente()));
            } catch (SQLException e) {
                e.printStackTrace();
                resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                respuesta.addProperty("error", "No se pudo consultar el saldo del cliente");
            }
        }
        resp.getWriter().write(respuesta.toString());
    }

    private JsonObject leerJson(HttpServletRequest req) throws IOException {
        StringBuilder cuerpo = new StringBuilder();
        String linea;
        while ((linea = req.getReader().readLine()) != null) {
            cuerpo.append(linea);
        }
        if (cuerpo.length() == 0) {
            return new JsonObject();
        }
        JsonElement elemento = JsonParser.parseString(cuerpo.toString());
        if (!elemento.isJsonObject()) {
            throw new JsonParseException("El cuerpo debe ser un objeto JSON");
        }
        return elemento.getAsJsonObject();
    }

    private String valor(JsonObject datos, String clave, String alternativa) {
        JsonElement elemento = datos.get(clave);
        return elemento == null || elemento.isJsonNull() ? alternativa : elemento.getAsString();
    }

    private int entero(JsonObject datos, String clave, String alternativa) {
        JsonElement elemento = datos.get(clave);
        return elemento == null || elemento.isJsonNull()
                ? Integer.parseInt(alternativa)
                : elemento.getAsInt();
    }

    private double decimal(JsonObject datos, String clave, String alternativa) {
        JsonElement elemento = datos.get(clave);
        if (elemento == null || elemento.isJsonNull()) {
            if (alternativa == null) {
                throw new NumberFormatException("Falta el valor de " + clave);
            }
            return Double.parseDouble(alternativa);
        }
        return elemento.getAsDouble();
    }

    private String limpiar(String valor) {
        return valor == null || valor.trim().isEmpty() ? null : valor.trim();
    }

    private void escribirEstado(HttpServletResponse resp, int status, String valor) throws IOException {
        resp.setStatus(status);
        JsonObject respuesta = new JsonObject();
        respuesta.addProperty("status", valor);
        resp.getWriter().write(respuesta.toString());
    }

    private void escribirError(HttpServletResponse resp, int status, String mensaje) throws IOException {
        resp.setStatus(status);
        JsonObject respuesta = new JsonObject();
        respuesta.addProperty("status", "ERROR");
        respuesta.addProperty("message", mensaje);
        resp.getWriter().write(respuesta.toString());
    }
}
