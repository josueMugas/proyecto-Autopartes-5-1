package com.demografia.controller;

import com.demografia.dao.FactoryDAO;
import com.demografia.dao.ICompraDAO;
import com.demografia.modelo.CompraResultado;
import com.demografia.modelo.DetalleCompra;
import com.demografia.modelo.Usuario;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

@WebServlet("/CompraServlet")
public class CompraServlet extends HttpServlet {

    private final ICompraDAO compraDAO = FactoryDAO.getCompraDAO();
    private final Gson gson = new Gson();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");

        HttpSession session = req.getSession(false);
        Usuario usuario = session == null ? null : (Usuario) session.getAttribute("usuarioLogueado");
        if (usuario == null) {
            escribirError(resp, HttpServletResponse.SC_UNAUTHORIZED, "Iniciá sesión para comprar.");
            return;
        }
        if (usuario.getIdRol() != 4 || usuario.getIdCliente() < 1) {
            escribirError(resp, HttpServletResponse.SC_FORBIDDEN, "Solo una cuenta de cliente puede comprar.");
            return;
        }

        DetalleCompra[] detalles;
        try {
            detalles = gson.fromJson(req.getReader(), DetalleCompra[].class);
        } catch (JsonParseException | IllegalStateException e) {
            escribirError(resp, HttpServletResponse.SC_BAD_REQUEST, "El carrito enviado no es válido.");
            return;
        }
        if (detalles == null || detalles.length == 0) {
            escribirError(resp, HttpServletResponse.SC_BAD_REQUEST, "El carrito está vacío.");
            return;
        }
        for (DetalleCompra detalle : detalles) {
            if (detalle == null || detalle.getIdProducto() < 1 || detalle.getCantidad() < 1) {
                escribirError(resp, HttpServletResponse.SC_BAD_REQUEST, "Revisá los productos y cantidades.");
                return;
            }
        }

        try {
            List<DetalleCompra> lista = Arrays.asList(detalles);
            CompraResultado resultado = compraDAO.confirmarCompra(
                    usuario.getIdCliente(), usuario.getIdUsuario(), lista);
            resp.getWriter().write(gson.toJson(resultado));
        } catch (SQLException e) {
            if ("45000".equals(e.getSQLState())) {
                escribirError(resp, HttpServletResponse.SC_CONFLICT, e.getMessage());
            } else {
                e.printStackTrace();
                escribirError(resp, HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                        "No se pudo confirmar la compra.");
            }
        }
    }

    private void escribirError(HttpServletResponse resp, int status, String mensaje) throws IOException {
        resp.setStatus(status);
        JsonObject respuesta = new JsonObject();
        respuesta.addProperty("status", "ERROR");
        respuesta.addProperty("message", mensaje);
        resp.getWriter().write(respuesta.toString());
    }
}
