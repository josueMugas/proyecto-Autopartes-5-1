package com.demografia.controller;

import com.demografia.dao.IHojaDeRutaDAO;
import com.demografia.dao.FactoryDAO;   
import com.demografia.modelo.HojaDeRuta;
import com.google.gson.Gson;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/HojaDeRutaServlet")
public class HojaDeRutaServlet extends HttpServlet {
    
    private final IHojaDeRutaDAO hojaDAO = FactoryDAO.getHojaDeRutaDAO();
    private final Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        
        String idParam = req.getParameter("id");
        if (idParam != null) {
            Integer id = Peticiones.id(idParam);
            if (id == null) {
                Peticiones.solicitudInvalida(resp, "El id debe ser numérico");
                return;
            }
            resp.getWriter().write(gson.toJson(hojaDAO.listById(id)));
        } else {
            resp.getWriter().write(gson.toJson(hojaDAO.listAll()));
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        
        HojaDeRuta hr = Peticiones.leerCuerpo(req, gson, HojaDeRuta.class);
        if (hr == null) {
            Peticiones.solicitudInvalida(resp, "El cuerpo de la solicitud no es válido");
            return;
        }
        boolean ok = (hr.getIdHojaRuta() > 0) ? hojaDAO.update(hr) : hojaDAO.insert(hr);
        resp.getWriter().write("{\"status\":\"" + (ok ? "OK" : "ERROR") + "\"}");
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        Integer id = Peticiones.id(req.getParameter("id"));
        if (id == null) {
            Peticiones.solicitudInvalida(resp, "Falta el id o no es numérico");
            return;
        }
        boolean ok = hojaDAO.delete(id);
        resp.getWriter().write("{\"status\":\"" + (ok ? "OK" : "ERROR") + "\"}");
    }
}