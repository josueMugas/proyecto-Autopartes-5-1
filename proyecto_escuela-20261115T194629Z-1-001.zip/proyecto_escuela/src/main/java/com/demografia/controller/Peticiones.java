package com.demografia.controller;

import com.google.gson.Gson;
import com.google.gson.JsonParseException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Utilidades compartidas por los servlets para validar la entrada
 * y responder 400 en lugar de lanzar excepciones.
 */
final class Peticiones {

    private Peticiones() {
    }

    /** Convierte un parámetro a entero; devuelve null si falta o no es numérico. */
    static Integer id(String valor) {
        if (valor == null) {
            return null;
        }
        try {
            return Integer.valueOf(valor.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /** Lee el cuerpo JSON; devuelve null si está vacío o mal formado. */
    static <T> T leerCuerpo(HttpServletRequest req, Gson gson, Class<T> tipo) throws IOException {
        try {
            return gson.fromJson(req.getReader(), tipo);
        } catch (JsonParseException e) {
            return null;
        }
    }

    static void solicitudInvalida(HttpServletResponse resp, String mensaje) throws IOException {
        resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        resp.getWriter().write("{\"status\":\"ERROR\",\"message\":\"" + mensaje + "\"}");
    }
}
