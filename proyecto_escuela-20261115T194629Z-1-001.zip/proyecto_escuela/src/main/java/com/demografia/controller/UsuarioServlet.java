package com.demografia.controller;

import com.demografia.dao.IUsuarioDAO;
import com.demografia.dao.FactoryDAO;
import com.demografia.modelo.Usuario;
import com.google.gson.Gson;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/UsuarioServlet")
public class UsuarioServlet extends HttpServlet {
    
    private final IUsuarioDAO usuarioDAO = FactoryDAO.getUsuarioDAO();
    private final Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        
        String idParam = req.getParameter("id");
        if (idParam != null) {
            Integer id = Peticiones.id(idParam);
            if (id == null) {
                Peticiones.solicitudInvalida(resp, "El id debe ser numérico");
                return;
            }
            resp.getWriter().write(gson.toJson(usuarioDAO.listById(id)));
        } else {
            resp.getWriter().write(gson.toJson(usuarioDAO.listAll()));
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        
        Usuario u = Peticiones.leerCuerpo(req, gson, Usuario.class);
        if (u == null) {
            Peticiones.solicitudInvalida(resp, "El cuerpo de la solicitud no es válido");
            return;
        }
        boolean ok = (u.getIdUsuario() > 0) ? usuarioDAO.update(u) : usuarioDAO.insert(u);
        resp.getWriter().write("{\"status\":\"" + (ok ? "OK" : "ERROR") + "\"}");
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        Integer id = Peticiones.id(req.getParameter("id"));
        if (id == null) {
            Peticiones.solicitudInvalida(resp, "Falta el id o no es numérico");
            return;
        }
        boolean esFisico = Boolean.parseBoolean(req.getParameter("fisico"));

        boolean ok = esFisico ? usuarioDAO.deleteFisico(id) : usuarioDAO.delete(id);
        resp.getWriter().write("{\"status\":\"" + (ok ? "OK" : "ERROR") + "\"}");
    }
}