package com.demografia.controller;

import com.demografia.dao.IInsumoDAO;
import com.demografia.dao.FactoryDAO;
import com.demografia.modelo.Insumo;
import com.google.gson.Gson;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/InsumoServlet")
public class InsumoServlet extends HttpServlet {
    
    private final IInsumoDAO insumoDAO = FactoryDAO.getInsumoDAO();
    private final Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        
        String idParam = req.getParameter("id");
        if (idParam != null) {
            Integer id = Peticiones.id(idParam);
            if (id == null) {
                Peticiones.solicitudInvalida(resp, "El id debe ser numérico");
                return;
            }
            resp.getWriter().write(gson.toJson(insumoDAO.listById(id)));
        } else {
            resp.getWriter().write(gson.toJson(insumoDAO.listAll()));
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        
        Insumo i = Peticiones.leerCuerpo(req, gson, Insumo.class);
        if ("reponer".equals(req.getParameter("accion"))) {
            if (i == null || i.getIdInsumo() < 1 || i.getStockActual() == null
                    || i.getStockActual().signum() <= 0) {
                resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Seleccioná un insumo e ingresá una cantidad positiva.");
                return;
            }
            boolean ok = insumoDAO.reponerStock(i.getIdInsumo(), i.getStockActual());
            resp.getWriter().write("{\"status\":\"" + (ok ? "OK" : "ERROR") + "\"}");
            return;
        }
        if (i == null) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Los datos del insumo no son válidos.");
            return;
        }
        boolean ok = (i.getIdInsumo() > 0) ? insumoDAO.update(i) : insumoDAO.insert(i);
        resp.getWriter().write("{\"status\":\"" + (ok ? "OK" : "ERROR") + "\"}");
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        Integer id = Peticiones.id(req.getParameter("id"));
        if (id == null) {
            Peticiones.solicitudInvalida(resp, "Falta el id o no es numérico");
            return;
        }
        boolean esFisico = Boolean.parseBoolean(req.getParameter("fisico"));

        boolean ok = esFisico ? insumoDAO.deleteFisico(id) : insumoDAO.delete(id);
        resp.getWriter().write("{\"status\":\"" + (ok ? "OK" : "ERROR") + "\"}");
    }
}