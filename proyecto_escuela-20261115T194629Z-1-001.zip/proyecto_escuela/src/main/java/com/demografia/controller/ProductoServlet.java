package com.demografia.controller;

import com.demografia.dao.IProductoDAO;
import com.demografia.dao.FactoryDAO;
import com.demografia.modelo.Producto;
import com.demografia.modelo.Usuario;
import com.google.gson.Gson;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/ProductoServlet")
public class ProductoServlet extends HttpServlet {
    
    private final IProductoDAO productoDAO = FactoryDAO.getProductoDAO();
    private final Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        
        String idParam = req.getParameter("id");
        String accion = req.getParameter("accion");
        if ("masVendidos".equals(accion)) {
            if (!esAdministrador(req)) {
                resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Solo los administradores pueden consultar este informe.");
                return;
            }
            resp.getWriter().write(gson.toJson(productoDAO.listTopSold()));
        } else if (idParam != null) {
            Integer id = Peticiones.id(idParam);
            if (id == null) {
                Peticiones.solicitudInvalida(resp, "El id debe ser numérico");
                return;
            }
            resp.getWriter().write(gson.toJson(productoDAO.listById(id)));
        } else {
            resp.getWriter().write(gson.toJson(productoDAO.listAll()));
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        if (!esAdministrador(req)) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Solo los administradores pueden modificar productos.");
            return;
        }

        Producto p = Peticiones.leerCuerpo(req, gson, Producto.class);
        if (p == null || p.getCodigo() == null || p.getCodigo().trim().isEmpty()
                || p.getNombre() == null || p.getNombre().trim().isEmpty()
                || p.getPrecioVenta() == null || p.getPrecioVenta().signum() <= 0) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Completá los datos del producto y su precio.");
            return;
        }
        boolean ok = (p.getIdProducto() > 0) ? productoDAO.update(p) : productoDAO.insert(p);
        resp.getWriter().write("{\"status\":\"" + (ok ? "OK" : "ERROR") + "\"}");
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        if (!esAdministrador(req)) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Solo los administradores pueden modificar productos.");
            return;
        }
        Integer id = Peticiones.id(req.getParameter("id"));
        if (id == null) {
            Peticiones.solicitudInvalida(resp, "Falta el id o no es numérico");
            return;
        }
        boolean esFisico = Boolean.parseBoolean(req.getParameter("fisico"));

        boolean ok = esFisico ? productoDAO.deleteFisico(id) : productoDAO.delete(id);
        resp.getWriter().write("{\"status\":\"" + (ok ? "OK" : "ERROR") + "\"}");
    }

    private boolean esAdministrador(HttpServletRequest req) {
        HttpSession session = req.getSession(false);
        Object usuarioSesion = session == null ? null : session.getAttribute("usuarioLogueado");
        return usuarioSesion instanceof Usuario && ((Usuario) usuarioSesion).getIdRol() == 1;
    }
}