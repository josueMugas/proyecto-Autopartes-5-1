package com.demografia.controller;

import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

@WebServlet("/testdb")
public class TestDB extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("text/plain");
        try (Connection conn = com.demografia.config.Conexion.getConnection()) {
            resp.getWriter().println("¡Conexión con la DB exitosa!");
        } catch (SQLException e) {
            log("No se pudo conectar con la base de datos", e);
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().println("No se pudo conectar con la base de datos.");
        }
    }
}