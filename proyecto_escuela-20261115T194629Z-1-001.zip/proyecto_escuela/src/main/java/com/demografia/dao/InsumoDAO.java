package com.demografia.dao;

import com.demografia.config.Conexion;
import com.demografia.modelo.Insumo;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class InsumoDAO implements IInsumoDAO {

    @Override
    public List<Insumo> listAll() {
        List<Insumo> lista = new ArrayList<>();
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_ListAll(?)}")) {
            statement.setString(1, "insumo");
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapearInsumo(rs));
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("No se pudo consultar la lista de insumos", e);
        }
        return lista;
    }

    @Override
    public boolean insert(Insumo insumo) {
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_Insert_Insumo(?, ?, ?, ?, ?, ?)}")) {
            statement.setString(1, insumo.getCodigo());
            statement.setString(2, insumo.getNombre());
            statement.setString(3, insumo.getTipoMaterial());
            statement.setBigDecimal(4, insumo.getStockActual());
            statement.setBigDecimal(5, insumo.getStockMinimo());
            statement.setString(6, insumo.getUnidadMedida());
            statement.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean delete(int id) {
        return actualizarEstado(id, false);
    }

    @Override
    public boolean deleteFisico(int id) {
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_DeleteFisico(?, ?, ?)}")) {
            statement.setString(1, "insumo");
            statement.setString(2, "id_insumo");
            statement.setInt(3, id);
            statement.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean update(Insumo insumo) {
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_Update_Insumo(?, ?, ?, ?, ?, ?, ?)}")) {
            statement.setInt(1, insumo.getIdInsumo());
            statement.setString(2, insumo.getCodigo());
            statement.setString(3, insumo.getNombre());
            statement.setString(4, insumo.getTipoMaterial());
            statement.setBigDecimal(5, insumo.getStockActual());
            statement.setBigDecimal(6, insumo.getStockMinimo());
            statement.setString(7, insumo.getUnidadMedida());
            statement.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public Insumo listById(int id) {
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_ListById(?, ?, ?)}")) {
            statement.setString(1, "insumo");
            statement.setString(2, "id_insumo");
            statement.setInt(3, id);
            try (ResultSet rs = statement.executeQuery()) {
                return rs.next() ? mapearInsumo(rs) : null;
            }
        } catch (SQLException e) {
            throw new IllegalStateException("No se pudo consultar el insumo", e);
        }
    }

    private boolean actualizarEstado(int id, boolean activo) {
        if (activo) {
            return false;
        }
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_Delete(?, ?, ?)}")) {
            statement.setString(1, "insumo");
            statement.setString(2, "id_insumo");
            statement.setInt(3, id);
            statement.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private Insumo mapearInsumo(ResultSet rs) throws SQLException {
        Insumo insumo = new Insumo(rs.getString("codigo"), rs.getString("nombre"),
                rs.getString("tipo_material"), rs.getBigDecimal("stock_actual"),
                rs.getBigDecimal("stock_minimo"), rs.getString("unidad_medida"));
        insumo.setIdInsumo(rs.getInt("id_insumo"));
        return insumo;
    }

    @Override
    public boolean reponerStock(int id, BigDecimal cantidad) {
        if (id < 1 || cantidad == null || cantidad.signum() <= 0) {
            throw new IllegalArgumentException("El insumo y la cantidad deben ser válidos");
        }
        Insumo insumo = listById(id);
        if (insumo == null) {
            return false;
        }
        insumo.setStockActual(insumo.getStockActual().add(cantidad));
        return update(insumo);
    }
}
