package com.demografia.dao;

import com.demografia.config.Conexion;
import com.demografia.modelo.CompraResultado;
import com.demografia.modelo.DetalleCompra;
import com.google.gson.Gson;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.math.BigDecimal;
import java.util.List;

public class CompraDAO implements ICompraDAO {

    private final Gson gson = new Gson();

    @Override
    public CompraResultado confirmarCompra(int idCliente, int idUsuario, List<DetalleCompra> detalles)
            throws SQLException {
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_ConfirmarCompra(?, ?, ?, ?, ?, ?)}")) {
            statement.setInt(1, idCliente);
            statement.setInt(2, idUsuario);
            statement.setString(3, gson.toJson(detalles));
            statement.registerOutParameter(4, Types.INTEGER);
            statement.registerOutParameter(5, Types.DECIMAL);
            statement.registerOutParameter(6, Types.DECIMAL);
            statement.execute();
            int idPresupuesto = statement.getInt(4);
            BigDecimal total = statement.getBigDecimal(5);
            BigDecimal saldoRestante = statement.getBigDecimal(6);
            if (idPresupuesto < 1 || total == null || saldoRestante == null) {
                throw new SQLException("El procedimiento no devolvió el resultado de compra esperado.");
            }
            return new CompraResultado(idPresupuesto, total, saldoRestante);
        }
    }
}
