package com.demografia.dao;

import com.demografia.config.Conexion;
import com.demografia.modelo.Presupuesto;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PresupuestoDAO implements IPresupuestoDAO {

    @Override
    public List<Presupuesto> listAll() {
        List<Presupuesto> lista = new ArrayList<>();
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_ListAll(?)}")) {
            statement.setString(1, "presupuesto");
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapearPresupuesto(rs));
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("No se pudo consultar la lista de presupuestos", e);
        }
        return lista;
    }

    @Override
    public boolean insert(Presupuesto presupuesto) {
        throw new UnsupportedOperationException("Los presupuestos se crean al confirmar una compra.");
    }

    @Override
    public boolean delete(int id) {
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_DeleteFisico(?, ?, ?)}")) {
            statement.setString(1, "presupuesto");
            statement.setString(2, "id_presupuesto");
            statement.setInt(3, id);
            statement.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean update(Presupuesto presupuesto) {
        throw new UnsupportedOperationException("Los presupuestos de una compra confirmada no se modifican.");
    }

    @Override
    public Presupuesto listById(int id) {
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_ListById(?, ?, ?)}")) {
            statement.setString(1, "presupuesto");
            statement.setString(2, "id_presupuesto");
            statement.setInt(3, id);
            try (ResultSet rs = statement.executeQuery()) {
                return rs.next() ? mapearPresupuesto(rs) : null;
            }
        } catch (SQLException e) {
            throw new IllegalStateException("No se pudo consultar el presupuesto", e);
        }
    }

    private Presupuesto mapearPresupuesto(ResultSet rs) throws SQLException {
        Presupuesto presupuesto = new Presupuesto(rs.getInt("id_cliente"), rs.getInt("id_usuario_venta"),
                rs.getDate("fecha"), rs.getDouble("total"), rs.getString("estado"),
                rs.getString("tipo_factura"), rs.getBoolean("es_formal"));
        presupuesto.setIdPresupuesto(rs.getInt("id_presupuesto"));
        return presupuesto;
    }
}
