package com.demografia.dao;

import com.demografia.config.Conexion;
import com.demografia.modelo.Cliente;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO implements IClienteDAO {

    @Override
    public List<Cliente> listAll() {
        List<Cliente> lista = new ArrayList<>();
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_ListAll(?)}")) {
            statement.setString(1, "cliente");
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapearCliente(rs));
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("No se pudo consultar la lista de clientes", e);
        }
        return lista;
    }

    @Override
    public Cliente listById(int id) {
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_ListById(?, ?, ?)}")) {
            statement.setString(1, "cliente");
            statement.setString(2, "id_cliente");
            statement.setInt(3, id);
            try (ResultSet rs = statement.executeQuery()) {
                return rs.next() ? mapearCliente(rs) : null;
            }
        } catch (SQLException e) {
            throw new IllegalStateException("No se pudo consultar el cliente", e);
        }
    }

    @Override
    public boolean insert(Cliente cliente) {
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_Insert_Cliente(?, ?, ?, ?, ?, ?)}")) {
            asignarDatos(statement, cliente, 1);
            statement.registerOutParameter(6, java.sql.Types.INTEGER);
            statement.execute();
            cliente.setIdCliente(statement.getInt(6));
            return cliente.getIdCliente() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean update(Cliente cliente) {
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_Update_Cliente(?, ?, ?, ?, ?, ?)}")) {
            statement.setInt(1, cliente.getIdCliente());
            asignarDatos(statement, cliente, 2);
            statement.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean delete(int id) {
        try (Connection con = Conexion.getConnection()) {
            con.setAutoCommit(false);
            try (CallableStatement cliente = con.prepareCall("{CALL sp_Delete(?, ?, ?)}");
                 CallableStatement usuario = con.prepareCall("{CALL sp_Delete(?, ?, ?)}")) {
                cliente.setString(1, "cliente");
                cliente.setString(2, "id_cliente");
                cliente.setInt(3, id);
                cliente.execute();
                usuario.setString(1, "usuario");
                usuario.setString(2, "id_cliente");
                usuario.setInt(3, id);
                usuario.execute();
                con.commit();
                return true;
            } catch (SQLException e) {
                con.rollback();
                throw e;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteFisico(int id) {
        try (Connection con = Conexion.getConnection()) {
            con.setAutoCommit(false);
            try (CallableStatement usuarios = con.prepareCall("{CALL sp_DeleteFisico(?, ?, ?)}");
                 CallableStatement cliente = con.prepareCall("{CALL sp_DeleteFisico(?, ?, ?)}")) {
                usuarios.setString(1, "usuario");
                usuarios.setString(2, "id_cliente");
                usuarios.setInt(3, id);
                usuarios.execute();
                cliente.setString(1, "cliente");
                cliente.setString(2, "id_cliente");
                cliente.setInt(3, id);
                cliente.execute();
                con.commit();
                return true;
            } catch (SQLException e) {
                con.rollback();
                throw e;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public double cargarSaldo(int idCliente, double monto) throws SQLException {
        if (idCliente < 1 || !Double.isFinite(monto) || monto <= 0) {
            throw new IllegalArgumentException("El cliente y el monto deben ser válidos");
        }

        try (Connection con = Conexion.getConnection()) {
            con.setAutoCommit(false);
            try {
                Cliente cliente = listarPorId(con, idCliente);
                if (cliente == null || !cliente.isActivo()) {
                    throw new SQLException("No existe un cliente activo con ese identificador");
                }
                try (CallableStatement statement = con.prepareCall("{CALL sp_CargarSaldoCliente(?, ?)}")) {
                    statement.setInt(1, idCliente);
                    statement.setDouble(2, monto);
                    statement.execute();
                }
                double saldo = listarPorId(con, idCliente).getSaldo();
                con.commit();
                return saldo;
            } catch (SQLException e) {
                con.rollback();
                throw e;
            }
        }
    }

    @Override
    public double obtenerSaldo(int idCliente) throws SQLException {
        try (Connection con = Conexion.getConnection()) {
            Cliente cliente = listarPorId(con, idCliente);
            if (cliente == null || !cliente.isActivo()) {
                throw new SQLException("No existe un cliente activo con ese identificador");
            }
            return cliente.getSaldo();
        }
    }

    private Cliente listarPorId(Connection con, int id) throws SQLException {
        try (CallableStatement statement = con.prepareCall("{CALL sp_ListById(?, ?, ?)}")) {
            statement.setString(1, "cliente");
            statement.setString(2, "id_cliente");
            statement.setInt(3, id);
            try (ResultSet rs = statement.executeQuery()) {
                return rs.next() ? mapearCliente(rs) : null;
            }
        }
    }

    private void asignarDatos(CallableStatement statement, Cliente cliente, int inicio) throws SQLException {
        statement.setString(inicio, cliente.getNombre());
        statement.setString(inicio + 1, cliente.getApellido());
        statement.setString(inicio + 2, cliente.getDni());
        statement.setString(inicio + 3, cliente.getTelefono());
        statement.setString(inicio + 4, cliente.getEmail());
    }

    private Cliente mapearCliente(ResultSet rs) throws SQLException {
        Cliente cliente = new Cliente();
        cliente.setIdCliente(rs.getInt("id_cliente"));
        cliente.setNombre(rs.getString("nombre"));
        cliente.setApellido(rs.getString("apellido"));
        cliente.setDni(rs.getString("dni"));
        cliente.setTelefono(rs.getString("telefono"));
        cliente.setEmail(rs.getString("email"));
        cliente.setSaldo(rs.getDouble("Saldo"));
        cliente.setActivo(rs.getBoolean("activo"));
        return cliente;
    }
}
