package com.demografia.dao;

import com.demografia.config.Conexion;
import com.demografia.modelo.Producto;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProductoDAO implements IProductoDAO {

    @Override
    public List<Producto> listAll() {
        try (Connection con = Conexion.getConnection()) {
            List<Producto> productos = listarProductos(con);
            Map<Integer, BigDecimal> existencias = listarExistencias(con);
            for (Producto producto : productos) {
                producto.setStockDisponible(calcularStockDisponible(con, producto.getIdProducto(), existencias));
            }
            return productos;
        } catch (SQLException e) {
            throw new IllegalStateException("No se pudo consultar la lista de productos", e);
        }
    }

    @Override
    public boolean insert(Producto producto) {
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_Insert_Producto(?, ?, ?, ?)}")) {
            statement.setString(1, producto.getCodigo());
            statement.setString(2, producto.getNombre());
            statement.setString(3, producto.getPlanoTecnicoUrl());
            statement.setBigDecimal(4, producto.getPrecioVenta());
            statement.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean delete(int id) {
        return actualizarEstado(id, false);
    }

    @Override
    public boolean deleteFisico(int id) {
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_DeleteFisico(?, ?, ?)}")) {
            statement.setString(1, "producto");
            statement.setString(2, "id_producto");
            statement.setInt(3, id);
            statement.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean update(Producto producto) {
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_Update_Producto(?, ?, ?, ?, ?)}")) {
            statement.setInt(1, producto.getIdProducto());
            statement.setString(2, producto.getCodigo());
            statement.setString(3, producto.getNombre());
            statement.setString(4, producto.getPlanoTecnicoUrl());
            statement.setBigDecimal(5, producto.getPrecioVenta());
            statement.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public Producto listById(int id) {
        try (Connection con = Conexion.getConnection()) {
            Producto producto;
            try (CallableStatement statement = con.prepareCall("{CALL sp_ListById(?, ?, ?)}")) {
                statement.setString(1, "producto");
                statement.setString(2, "id_producto");
                statement.setInt(3, id);
                try (ResultSet rs = statement.executeQuery()) {
                    if (!rs.next()) {
                        return null;
                    }
                    producto = mapearProducto(rs);
                }
            }
            producto.setStockDisponible(calcularStockDisponible(con, producto.getIdProducto(), listarExistencias(con)));
            return producto;
        } catch (SQLException e) {
            throw new IllegalStateException("No se pudo consultar el producto", e);
        }
    }

    @Override
    public List<Producto> listTopSold() {
        List<Producto> productos = new ArrayList<>();
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_ProductosMasVendidos()}");
             ResultSet rs = statement.executeQuery()) {
            while (rs.next()) {
                Producto producto = new Producto(rs.getString("codigo"), rs.getString("nombre"), null);
                producto.setIdProducto(rs.getInt("id_producto"));
                producto.setTotalVendido(rs.getLong("total_vendido"));
                productos.add(producto);
            }
            return productos;
        } catch (SQLException e) {
            throw new IllegalStateException("No se pudieron consultar los productos más vendidos", e);
        }
    }

    private boolean actualizarEstado(int id, boolean activo) {
        if (activo) {
            return false;
        }
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_Delete(?, ?, ?)}")) {
            statement.setString(1, "producto");
            statement.setString(2, "id_producto");
            statement.setInt(3, id);
            statement.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private List<Producto> listarProductos(Connection con) throws SQLException {
        List<Producto> productos = new ArrayList<>();
        try (CallableStatement statement = con.prepareCall("{CALL sp_ListAll(?)}")) {
            statement.setString(1, "producto");
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    productos.add(mapearProducto(rs));
                }
            }
        }
        return productos;
    }

    private Map<Integer, BigDecimal> listarExistencias(Connection con) throws SQLException {
        Map<Integer, BigDecimal> existencias = new HashMap<>();
        try (CallableStatement statement = con.prepareCall("{CALL sp_ListAll(?)}")) {
            statement.setString(1, "insumo");
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    existencias.put(rs.getInt("id_insumo"), rs.getBigDecimal("stock_actual"));
                }
            }
        }
        return existencias;
    }

    private int calcularStockDisponible(Connection con, int idProducto, Map<Integer, BigDecimal> existencias)
            throws SQLException {
        int disponible = Integer.MAX_VALUE;
        boolean tieneReceta = false;
        try (CallableStatement statement = con.prepareCall("{CALL sp_ListById(?, ?, ?)}")) {
            statement.setString(1, "producto_insumo");
            statement.setString(2, "id_producto");
            statement.setInt(3, idProducto);
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    tieneReceta = true;
                    BigDecimal requerido = rs.getBigDecimal("cantidad_requerida");
                    BigDecimal existencia = existencias.get(rs.getInt("id_insumo"));
                    if (requerido == null || requerido.signum() <= 0 || existencia == null) {
                        return 0;
                    }
                    if (existencia.signum() < 0) {
                        return 0;
                    }
                    BigDecimal cantidadFabricable = existencia.divideToIntegralValue(requerido);
                    int fabricables = cantidadFabricable.compareTo(BigDecimal.valueOf(Integer.MAX_VALUE)) > 0
                            ? Integer.MAX_VALUE : cantidadFabricable.intValue();
                    disponible = Math.min(disponible, fabricables);
                }
            }
        }
        return tieneReceta ? disponible : 0;
    }

    private Producto mapearProducto(ResultSet rs) throws SQLException {
        Producto producto = new Producto(rs.getString("codigo"), rs.getString("nombre"),
                rs.getString("plano_tecnico_url"));
        producto.setIdProducto(rs.getInt("id_producto"));
        producto.setPrecioVenta(rs.getBigDecimal("precio_venta"));
        return producto;
    }
}
