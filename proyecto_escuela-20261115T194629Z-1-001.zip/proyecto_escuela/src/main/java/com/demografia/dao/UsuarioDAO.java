package com.demografia.dao;

import com.demografia.config.Conexion;
import com.demografia.modelo.Usuario;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO implements IUsuarioDAO {

    @Override
    public List<Usuario> listAll() {
        try (Connection con = Conexion.getConnection()) {
            return listarUsuarios(con);
        } catch (SQLException e) {
            throw new IllegalStateException("No se pudo consultar la lista de usuarios", e);
        }
    }

    @Override
    public boolean insert(Usuario usuario) {
        try (Connection con = Conexion.getConnection()) {
            if (nombreUsuarioActivoExiste(con, usuario.getNombreUsuario())) {
                return false;
            }
            try (CallableStatement statement = con.prepareCall("{CALL sp_Insert_Usuario(?, ?, ?, ?)}")) {
                statement.setString(1, usuario.getNombreUsuario());
                statement.setString(2, usuario.getClave());
                statement.setInt(3, usuario.getIdRol());
                statement.setNull(4, Types.INTEGER);
                statement.execute();
                return true;
            }
        } catch (SQLException e) {
            throw new IllegalStateException("No se pudo insertar el usuario.", e);
        }
    }

    @Override
    public boolean insertCliente(Usuario usuario, String nombre, String apellido, String email, String telefono) {
        try (Connection con = Conexion.getConnection()) {
            con.setAutoCommit(false);
            try {
                if (nombreUsuarioActivoExiste(con, usuario.getNombreUsuario())) {
                    con.rollback();
                    return false;
                }

                int idCliente;
                try (CallableStatement clienteStatement = con.prepareCall(
                        "{CALL sp_Insert_Cliente(?, ?, ?, ?, ?, ?)}")) {
                    clienteStatement.setString(1, nombre);
                    clienteStatement.setString(2, apellido);
                    clienteStatement.setNull(3, Types.VARCHAR);
                    clienteStatement.setString(4, telefono);
                    clienteStatement.setString(5, email);
                    clienteStatement.registerOutParameter(6, Types.INTEGER);
                    clienteStatement.execute();
                    idCliente = clienteStatement.getInt(6);
                }

                if (idCliente < 1) {
                    throw new SQLException("No se obtuvo el identificador del cliente creado.");
                }

                try (CallableStatement usuarioStatement = con.prepareCall(
                        "{CALL sp_Insert_Usuario(?, ?, ?, ?)}")) {
                    usuarioStatement.setString(1, usuario.getNombreUsuario());
                    usuarioStatement.setString(2, usuario.getClave());
                    usuarioStatement.setInt(3, usuario.getIdRol());
                    usuarioStatement.setInt(4, idCliente);
                    usuarioStatement.execute();
                }

                usuario.setIdCliente(idCliente);
                con.commit();
                return true;
            } catch (SQLException e) {
                try {
                    con.rollback();
                } catch (SQLException rollbackError) {
                    e.addSuppressed(rollbackError);
                }
                throw e;
            }
        } catch (SQLException e) {
            throw new IllegalStateException("No se pudo registrar el cliente y su usuario.", e);
        }
    }

    @Override
    public boolean delete(int id) {
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_Delete(?, ?, ?)}")) {
            statement.setString(1, "usuario");
            statement.setString(2, "id_usuario");
            statement.setInt(3, id);
            statement.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteFisico(int id) {
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_DeleteFisico(?, ?, ?)}")) {
            statement.setString(1, "usuario");
            statement.setString(2, "id_usuario");
            statement.setInt(3, id);
            statement.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean update(Usuario usuario) {
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_Update_Usuario(?, ?, ?, ?, ?)}")) {
            statement.setInt(1, usuario.getIdUsuario());
            statement.setString(2, usuario.getNombreUsuario());
            statement.setString(3, usuario.getClave());
            statement.setBoolean(4, usuario.isActivo());
            statement.setInt(5, usuario.getIdRol());
            statement.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public Usuario listById(int id) {
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_ListById(?, ?, ?)}")) {
            statement.setString(1, "usuario");
            statement.setString(2, "id_usuario");
            statement.setInt(3, id);
            try (ResultSet rs = statement.executeQuery()) {
                return rs.next() ? mapearUsuario(rs) : null;
            }
        } catch (SQLException e) {
            throw new IllegalStateException("No se pudo consultar el usuario", e);
        }
    }

    private List<Usuario> listarUsuarios(Connection con) throws SQLException {
        List<Usuario> lista = new ArrayList<>();
        try (CallableStatement statement = con.prepareCall("{CALL sp_ListAll(?)}")) {
            statement.setString(1, "usuario");
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapearUsuario(rs));
                }
            }
        }
        return lista;
    }

    private boolean nombreUsuarioActivoExiste(Connection con, String nombreUsuario) throws SQLException {
        return listarUsuarios(con).stream()
                .anyMatch(usuario -> usuario.getNombreUsuario() != null
                        && usuario.getNombreUsuario().equalsIgnoreCase(nombreUsuario));
    }

    private Usuario mapearUsuario(ResultSet rs) throws SQLException {
        Usuario usuario = new Usuario(rs.getString("nombre_usuario"), rs.getString("clave"),
                rs.getBoolean("activo"), rs.getInt("id_rol"));
        usuario.setIdUsuario(rs.getInt("id_usuario"));
        usuario.setIdCliente(rs.getInt("id_cliente"));
        return usuario;
    }
}
