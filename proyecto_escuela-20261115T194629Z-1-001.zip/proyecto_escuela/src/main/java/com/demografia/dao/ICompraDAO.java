package com.demografia.dao;

import com.demografia.modelo.CompraResultado;
import com.demografia.modelo.DetalleCompra;
import java.sql.SQLException;
import java.util.List;

public interface ICompraDAO {
    CompraResultado confirmarCompra(int idCliente, int idUsuario, List<DetalleCompra> detalles)
            throws SQLException;
}
