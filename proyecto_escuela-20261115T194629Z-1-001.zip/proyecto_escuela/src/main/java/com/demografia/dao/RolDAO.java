package com.demografia.dao;

import com.demografia.config.Conexion;
import com.demografia.modelo.Rol;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class RolDAO implements IRolDAO {

    @Override
    public List<Rol> listAll() {
        List<Rol> lista = new ArrayList<>();
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_ListAll(?)}")) {
            statement.setString(1, "rol");
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    Rol rol = mapearRol(rs);
                    lista.add(rol);
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("No se pudo consultar la lista de roles", e);
        }
        return lista;
    }

    @Override
    public boolean insert(Rol rol) {
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_Insert_Rol(?, ?)}")) {
            statement.setString(1, rol.getNombreRol());
            statement.setString(2, rol.getDescripcion());
            statement.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean delete(int id) {
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_DeleteFisico(?, ?, ?)}")) {
            statement.setString(1, "rol");
            statement.setString(2, "id_rol");
            statement.setInt(3, id);
            statement.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean update(Rol rol) {
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_Update_Rol(?, ?, ?, ?)}")) {
            statement.setString(1, rol.getNombreRol());
            statement.setString(2, rol.getDescripcion());
            statement.setInt(3, rol.getIdRol());
            statement.registerOutParameter(4, Types.INTEGER);
            statement.execute();
            return statement.getInt(4) == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public Rol listById(int id) {
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_ListById(?, ?, ?)}")) {
            statement.setString(1, "rol");
            statement.setString(2, "id_rol");
            statement.setInt(3, id);
            try (ResultSet rs = statement.executeQuery()) {
                return rs.next() ? mapearRol(rs) : null;
            }
        } catch (SQLException e) {
            throw new IllegalStateException("No se pudo consultar el rol", e);
        }
    }

    private Rol mapearRol(ResultSet rs) throws SQLException {
        Rol rol = new Rol(rs.getString("nombre_rol"), rs.getString("descripcion"));
        rol.setIdRol(rs.getInt("id_rol"));
        return rol;
    }
}
