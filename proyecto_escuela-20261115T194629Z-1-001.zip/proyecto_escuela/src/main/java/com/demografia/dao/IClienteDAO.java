package com.demografia.dao;

import com.demografia.modelo.Cliente;
import java.sql.SQLException;
import java.util.List;

public interface IClienteDAO {
    double cargarSaldo(int idCliente, double monto) throws SQLException;
    double obtenerSaldo(int idCliente) throws SQLException;
    List<Cliente> listAll();
    boolean insert(Cliente cliente);
    boolean delete(int id);
    boolean deleteFisico(int id);
    boolean update(Cliente cliente);
    Cliente listById(int id);
}