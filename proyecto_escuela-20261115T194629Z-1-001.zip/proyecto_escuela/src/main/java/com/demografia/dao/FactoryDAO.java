package com.demografia.dao;

public class FactoryDAO {

    public static IClienteDAO getClienteDAO() {
        return new ClienteDAO();
    }

    public static IUsuarioDAO getUsuarioDAO() {
        return new UsuarioDAO();
    }

    public static IProductoDAO getProductoDAO() {
        return new ProductoDAO();
    }

    public static IInsumoDAO getInsumoDAO() {
        return new InsumoDAO();
    }

    public static IPresupuestoDAO getPresupuestoDAO() {
        return new PresupuestoDAO();
    }

    public static ICompraDAO getCompraDAO() {
        return new CompraDAO();
    }

    public static IHojaDeRutaDAO getHojaDeRutaDAO() {
        return new HojaDeRutaDAO();
    }

    public static IRolDAO getRolDAO() {
        return new RolDAO();
    }
}