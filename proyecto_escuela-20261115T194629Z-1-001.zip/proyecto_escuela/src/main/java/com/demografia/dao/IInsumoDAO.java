package com.demografia.dao;

import com.demografia.modelo.Insumo;
import java.math.BigDecimal;
import java.util.List;

public interface IInsumoDAO {
    List<Insumo> listAll();
    boolean insert(Insumo insumo);
    boolean delete(int id);
    boolean deleteFisico(int id);
    boolean update(Insumo insumo);
    Insumo listById(int id);
    boolean reponerStock(int id, BigDecimal cantidad);
}