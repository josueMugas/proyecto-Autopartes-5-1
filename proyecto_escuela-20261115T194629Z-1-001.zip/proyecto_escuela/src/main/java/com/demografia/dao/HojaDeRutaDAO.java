package com.demografia.dao;

import com.demografia.config.Conexion;
import com.demografia.modelo.HojaDeRuta;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class HojaDeRutaDAO implements IHojaDeRutaDAO {

    @Override
    public List<HojaDeRuta> listAll() {
        List<HojaDeRuta> lista = new ArrayList<>();
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_ListAll(?)}")) {
            statement.setString(1, "hoja_de_ruta");
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapearHojaDeRuta(rs));
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("No se pudo consultar la lista de hojas de ruta", e);
        }
        return lista;
    }

    @Override
    public boolean insert(HojaDeRuta hoja) {
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_Insert_HojaDeRuta(?, ?, ?, ?, ?, ?, ?, ?, ?)}")) {
            asignarParametros(statement, hoja, false);
            statement.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean delete(int id) {
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_DeleteFisico(?, ?, ?)}")) {
            statement.setString(1, "hoja_de_ruta");
            statement.setString(2, "id_hoja_ruta");
            statement.setInt(3, id);
            statement.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean update(HojaDeRuta hoja) {
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall(
                     "{CALL sp_Update_HojaDeRuta(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}")) {
            asignarParametros(statement, hoja, true);
            statement.registerOutParameter(11, Types.INTEGER);
            statement.execute();
            return statement.getInt(11) == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public HojaDeRuta listById(int id) {
        try (Connection con = Conexion.getConnection();
             CallableStatement statement = con.prepareCall("{CALL sp_ListById(?, ?, ?)}")) {
            statement.setString(1, "hoja_de_ruta");
            statement.setString(2, "id_hoja_ruta");
            statement.setInt(3, id);
            try (ResultSet rs = statement.executeQuery()) {
                return rs.next() ? mapearHojaDeRuta(rs) : null;
            }
        } catch (SQLException e) {
            throw new IllegalStateException("No se pudo consultar la hoja de ruta", e);
        }
    }

    private void asignarParametros(CallableStatement statement, HojaDeRuta hoja, boolean incluirId)
            throws SQLException {
        statement.setString(1, hoja.getCodigoInalterable());
        statement.setInt(2, hoja.getIdPresupuesto());
        statement.setInt(3, hoja.getIdProducto());
        statement.setInt(4, hoja.getCantidad());
        statement.setString(5, hoja.getLineaTrabajo());
        statement.setString(6, hoja.getMetodoProductivo());
        statement.setString(7, hoja.getEstado());
        statement.setDate(8, fechaSql(hoja.getFechaInicio()));
        statement.setDate(9, fechaSql(hoja.getFechaEstimadaEntrega()));
        if (incluirId) {
            statement.setInt(10, hoja.getIdHojaRuta());
        }
    }

    private java.sql.Date fechaSql(java.util.Date fecha) {
        return fecha == null ? null : new java.sql.Date(fecha.getTime());
    }

    private HojaDeRuta mapearHojaDeRuta(ResultSet rs) throws SQLException {
        HojaDeRuta hoja = new HojaDeRuta(rs.getString("codigo_inalterable"),
                rs.getInt("id_presupuesto"), rs.getInt("id_producto"), rs.getInt("cantidad"),
                rs.getString("linea_trabajo"), rs.getString("metodo_productivo"), rs.getString("estado"),
                rs.getDate("fecha_inicio"), rs.getDate("fecha_estimada_entrega"));
        hoja.setIdHojaRuta(rs.getInt("id_hoja_ruta"));
        return hoja;
    }
}
