package com.demografia.config;

import java.io.IOException;

import com.demografia.modelo.Usuario;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebFilter(urlPatterns = {"/panel_admin.html", "/productos.html", "/clientes_admin.html", "/ClienteServlet",
        "/InsumoServlet", "/PresupuestoServlet", "/UsuarioServlet", "/RolServlet"})
public class AdminPanelFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        HttpSession session = httpRequest.getSession(false);
        Usuario usuario = session == null ? null : (Usuario) session.getAttribute("usuarioLogueado");

        if (usuario == null) {
            httpResponse.sendRedirect(httpRequest.getContextPath() + "/login.html");
            return;
        }
        if (usuario.getIdRol() != 1) {
            httpResponse.sendError(HttpServletResponse.SC_FORBIDDEN, "Solo los administradores pueden acceder a este panel.");
            return;
        }

        chain.doFilter(request, response);
    }
}
