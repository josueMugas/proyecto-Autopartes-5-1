const CLAVE_CARRITO = 'autopartes-carrito-v1';
let carrito = cargarCarritoGuardado();

function cargarCarritoGuardado() {
    try {
        const guardado = sessionStorage.getItem(CLAVE_CARRITO);
        const items = guardado ? JSON.parse(guardado) : [];
        return Array.isArray(items) ? items.filter(item =>
            Number.isInteger(Number(item.idProducto)) &&
            Number(item.idProducto) > 0 &&
            Number.isInteger(Number(item.cantidad)) &&
            Number(item.cantidad) > 0
        ) : [];
    } catch (error) {
        console.error('No se pudo leer el carrito guardado:', error);
        return [];
    }
}

function guardarCarrito() {
    sessionStorage.setItem(CLAVE_CARRITO, JSON.stringify(carrito));
    actualizarContadorCarrito();
}

function actualizarContadorCarrito() {
    const contador = document.getElementById('contador-carrito');
    if (!contador) return;
    contador.textContent = String(carrito.reduce((total, item) => total + Number(item.cantidad), 0));
}

function agregarAlCarrito(idProducto) {
    const producto = window.productosCatalogo
        ? window.productosCatalogo.find(item => Number(item.idProducto) === Number(idProducto))
        : null;
    if (!producto) {
        alert('No se encontró el producto seleccionado.');
        return;
    }
    if (Number(producto.precioVenta) <= 0) {
        alert('Este producto todavía no tiene un precio de venta.');
        return;
    }

    const itemExistente = carrito.find(item => Number(item.idProducto) === Number(producto.idProducto));
    if (itemExistente) {
        if (itemExistente.cantidad >= Number(producto.stockDisponible)) {
            alert('No hay más stock disponible para este producto.');
            return;
        }
        itemExistente.cantidad += 1;
    } else {
        carrito.push({
            idProducto: Number(producto.idProducto),
            nombre: String(producto.nombre),
            codigo: String(producto.codigo),
            stockDisponible: Number(producto.stockDisponible),
            precioVenta: Number(producto.precioVenta) || 0,
            cantidad: 1
        });
    }
    guardarCarrito();
    renderizarCarrito();
    alert(`${producto.nombre} se agregó al carrito.`);
}

function renderizarCarrito() {
    const tbody = document.querySelector('#tabla-carrito tbody');
    if (!tbody) {
        actualizarContadorCarrito();
        return;
    }

    tbody.innerHTML = carrito.length
        ? carrito.map((item, index) => `
            <tr>
                <td>${escaparCarrito(item.nombre)}</td>
                <td>${escaparCarrito(item.codigo)}</td>
                <td>${formatearCarrito(item.precioVenta)}</td>
                <td>
                    <input type="number" min="1" max="${item.stockDisponible}"
                        value="${item.cantidad}" aria-label="Cantidad"
                        onchange="cambiarCantidadCarrito(${index}, this.value)">
                </td>
                <td>${formatearCarrito(Number(item.precioVenta) * Number(item.cantidad))}</td>
                <td><button type="button" class="btn-danger" onclick="eliminarDelCarrito(${index})">Quitar</button></td>
            </tr>
        `).join('')
        : '<tr><td colspan="6">Todavía no agregaste productos.</td></tr>';
    const total = carrito.reduce((suma, item) =>
        suma + (Number(item.precioVenta) || 0) * Number(item.cantidad), 0);
    const totalElemento = document.getElementById('total-carrito');
    if (totalElemento) totalElemento.textContent = formatearCarrito(total);
    const botonCompra = document.getElementById('btn-confirmar-compra');
    if (botonCompra) {
        botonCompra.disabled = !carrito.length || carrito.some(item =>
            !Number.isInteger(Number(item.cantidad)) ||
            Number(item.cantidad) > Number(item.stockDisponible) ||
            !Number.isFinite(Number(item.precioVenta)) ||
            Number(item.precioVenta) <= 0
        );
    }
    actualizarContadorCarrito();
}

function cambiarCantidadCarrito(index, cantidadIngresada) {
    const item = carrito[index];
    if (!item) return;
    const cantidad = Number(cantidadIngresada);
    if (!Number.isInteger(cantidad) || cantidad < 1 || cantidad > item.stockDisponible) {
        alert(`La cantidad debe estar entre 1 y ${item.stockDisponible}.`);
        renderizarCarrito();
        return;
    }
    item.cantidad = cantidad;
    guardarCarrito();
    renderizarCarrito();
}

function eliminarDelCarrito(index) {
    carrito.splice(index, 1);
    guardarCarrito();
    renderizarCarrito();
}

function escaparCarrito(valor) {
    const elemento = document.createElement('span');
    elemento.textContent = valor == null ? '' : String(valor);
    return elemento.innerHTML;
}

function formatearCarrito(valor) {
    return Number(valor || 0).toLocaleString('es-AR', { style: 'currency', currency: 'ARS' });
}

async function sincronizarCarrito() {
    if (!document.getElementById('tabla-carrito') || !carrito.length) {
        renderizarCarrito();
        return;
    }
    try {
        const respuesta = await fetch(`${API_BASE}/ProductoServlet`);
        if (!respuesta.ok) throw new Error(`No se pudo actualizar el catálogo (${respuesta.status})`);
        const productos = await respuesta.json();
        carrito = carrito.filter(item => {
            const producto = productos.find(actual => Number(actual.idProducto) === Number(item.idProducto));
            if (!producto) return false;
            item.nombre = String(producto.nombre);
            item.codigo = String(producto.codigo);
            item.stockDisponible = Number(producto.stockDisponible) || 0;
            item.precioVenta = Number(producto.precioVenta) || 0;
            return true;
        });
        guardarCarrito();
        renderizarCarrito();
    } catch (error) {
        console.error('Error al actualizar los productos del carrito:', error);
        mostrarMensajeCarrito('No se pudieron actualizar los precios y el stock. Intentá nuevamente.');
    }
}

async function confirmarCompra() {
    if (!carrito.length) return;
    const boton = document.getElementById('btn-confirmar-compra');
    boton.disabled = true;
    try {
        const respuesta = await fetch(`${API_BASE}/CompraServlet`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(carrito.map(item => ({
                idProducto: Number(item.idProducto),
                cantidad: Number(item.cantidad)
            })))
        });
        const resultado = await respuesta.json();
        if (!respuesta.ok) {
            throw new Error(resultado.message || 'No se pudo completar la compra.');
        }
        carrito = [];
        guardarCarrito();
        renderizarCarrito();
        mostrarMensajeCarrito(
            `Compra confirmada. Presupuesto #${resultado.idPresupuesto}, total ${formatearCarrito(resultado.total)}. Saldo restante: ${formatearCarrito(resultado.saldoRestante)}.`,
            'success'
        );
    } catch (error) {
        console.error('Error al confirmar la compra:', error);
        mostrarMensajeCarrito(error.message || 'No se pudo completar la compra. Revisá tu saldo e intentá nuevamente.');
        renderizarCarrito();
    }
}

function mostrarMensajeCarrito(mensaje, tipo = 'danger') {
    const alerta = document.getElementById('mensaje-carrito');
    if (!alerta) return;
    alerta.textContent = mensaje;
    alerta.className = `alert alert-${tipo}`;
}

document.addEventListener('DOMContentLoaded', () => {
    actualizarContadorCarrito();
    renderizarCarrito();
    sincronizarCarrito();
});
