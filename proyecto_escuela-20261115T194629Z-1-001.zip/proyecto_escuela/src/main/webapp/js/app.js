const API_BASE = '/proyecto_escuela';

function redirigirSegunRol(idRol) {
    if (idRol === 1) {
        window.location.href = 'panel_admin.html';
    } else if (idRol === 4) {
        window.location.href = 'panel_cliente.html';
    } else {
        window.location.href = 'productos.html';
    }
}

async function verificarSesion(rolRequerido) {
    try {
        const res = await fetch(`${API_BASE}/AuthServlet`);
        if (!res.ok) {
            throw new Error(`Error al verificar la sesión (${res.status})`);
        }
        const data = await res.json();

        if (!data.autenticado) {
            window.location.href = 'login.html';
            return false;
        }

        const idRol = Number(data.usuario && data.usuario.idRol);
        if (idRol === 1) {
            const linkAdmin = document.getElementById('link-admin');
            if (linkAdmin) linkAdmin.classList.remove('hidden');
        }

        const rolesPermitidos = Array.isArray(rolRequerido) ? rolRequerido : [rolRequerido];
        if (rolRequerido != null && !rolesPermitidos.includes(idRol)) {
            redirigirSegunRol(idRol);
            return false;
        }

        return true;
    } catch (e) {
        console.error('Error al verificar la sesión:', e);
        window.location.href = 'login.html';
        return false;
    }
}

async function cerrarSesion() {
    try {
        await fetch(`${API_BASE}/AuthServlet?action=logout`, { method: 'POST' });
    } finally {
        sessionStorage.removeItem('autopartes-carrito-v1');
        window.location.href = 'login.html';
    }
}

async function borradoLogico(id, servlet) {
    if (!confirm('¿Desea realizar el borrado lógico (desactivar)?')) return;
    await fetch(`${API_BASE}/${servlet}?id=${id}&fisico=false`, { method: 'DELETE' });
    location.reload();
}

async function borradoFisico(id, servlet) {
    if (!confirm('¡ATENCIÓN! Esto eliminará el registro permanentemente de la base de datos.')) return;
    await fetch(`${API_BASE}/${servlet}?id=${id}&fisico=true`, { method: 'DELETE' });
    location.reload();
}