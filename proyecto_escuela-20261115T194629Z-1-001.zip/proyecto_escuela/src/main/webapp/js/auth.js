const API_BASE = '/proyecto_escuela';

function actualizarCamposCliente() {
    const rol = document.getElementById('reg-rol');
    const campos = document.getElementById('campos-cliente');
    if (!(rol instanceof HTMLSelectElement) || !campos) {
        return;
    }

    const esCliente = rol.value === '4';
    campos.classList.toggle('hidden', !esCliente);
    ['reg-nombre', 'reg-apellido'].forEach(id => {
        const campo = document.getElementById(id);
        if (campo instanceof HTMLInputElement) campo.required = esCliente;
    });
}

document.addEventListener('DOMContentLoaded', () => {
    const rol = document.getElementById('reg-rol');
    if (rol) rol.addEventListener('change', actualizarCamposCliente);
    actualizarCamposCliente();
});

function ejecutarLogin(event) {
    event.preventDefault();
    const campoUsuario = document.getElementById('login-usuario');
    const campoClave = document.getElementById('login-clave');
    if (!(campoUsuario instanceof HTMLInputElement) || !(campoClave instanceof HTMLInputElement)) {
        mostrarAlerta("No se encontraron los campos de usuario y contraseña.", "danger");
        return;
    }

    const nombreUsuario = campoUsuario.value;
    const clave = campoClave.value;

    fetch(`${API_BASE}/AuthServlet?action=login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nombreUsuario, clave })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === "OK") {
            const idRol = Number(data.idRol);
            if (idRol === 1) {
                window.location.href = "panel_admin.html";
            } else if (idRol === 4) {
                window.location.href = "panel_cliente.html";
            } else {
                window.location.href = "productos.html";
            }
        } else {
            alert("Error: " + (data.message || "Credenciales inválidas"));
        }
    })
    .catch(err => {
        console.error("Error en login:", err);
        alert("No se pudo iniciar sesión. Revisá la conexión e intentá nuevamente.");
    });
}
function ejecutarRegistro(event) {
    event.preventDefault();

    const nombreUsuario = document.getElementById('reg-usuario').value.trim();
    const clave = document.getElementById('reg-clave').value;
    const idRol = Number(document.getElementById('reg-rol').value);
    const payload = {
        nombreUsuario,
        clave,
        idRol,
        nombre: document.getElementById('reg-nombre').value.trim(),
        apellido: document.getElementById('reg-apellido').value.trim(),
        email: document.getElementById('reg-email').value.trim(),
        telefono: document.getElementById('reg-telefono').value.trim()
    };

    fetch(`${API_BASE}/AuthServlet?action=register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    })
    .then(async res => ({ ok: res.ok, data: await res.json() }))
    .then(({ ok, data }) => {
        if (ok && data.status === "OK") {
            alert("¡Registro exitoso! Ya podés iniciar sesión.");
            window.location.href = "login.html";
        } else {
            mostrarAlerta(data.message || "No se pudo registrar el usuario.", "danger");
        }
    })
    .catch(err => {
        console.error("Error en registro:", err);
        mostrarAlerta("No se pudo completar el registro. Revisá la conexión e intentá nuevamente.", "danger");
    });
}

function mostrarAlerta(msg, tipo) {
    const box = document.getElementById('auth-alert');
    if (!box) return;
    box.innerText = msg;
    box.className = `alert alert-${tipo}`;
}

function ocultarAlerta() {
    const box = document.getElementById('auth-alert');
    if (!box) return;
    box.className = 'alert hidden';
}