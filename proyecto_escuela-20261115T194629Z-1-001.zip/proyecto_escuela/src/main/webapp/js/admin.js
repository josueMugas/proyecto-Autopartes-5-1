const SERVLETS_ADMIN = {
    cliente: 'ClienteServlet',
    producto: 'ProductoServlet',
    insumo: 'InsumoServlet',
    usuario: 'UsuarioServlet'
};

async function obtenerListaAdmin(servlet) {
    let respuesta;
    try {
        respuesta = await fetch(`${API_BASE}/${servlet}`);
    } catch (error) {
        throw new Error(`No se pudo contactar ${servlet}: ${error.message}`);
    }
    if (!respuesta.ok) {
        throw new Error(`${servlet} respondió con error HTTP ${respuesta.status}.`);
    }

    let datos;
    try {
        datos = await respuesta.json();
    } catch {
        throw new Error(`${servlet} no devolvió JSON válido; revisá la sesión y el registro del servidor.`);
    }
    if (!Array.isArray(datos)) {
        throw new Error(`${servlet} no devolvió una lista de datos.`);
    }
    return datos;
}

function escaparHTML(valor) {
    return String(valor == null ? '' : valor).replace(/[&<>"']/g, caracter => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
    })[caracter]);
}

function mostrarMensajeAdmin(mensaje, tipo = 'danger') {
    const alerta = document.getElementById('admin-alert');
    if (!alerta) {
        alert(mensaje);
        return;
    }
    alerta.textContent = mensaje;
    alerta.className = `alert alert-${tipo}`;
}

async function cargarDashboardAdmin() {
    try {
        const [clientes, presupuestos, insumos, productos, masVendidos] = await Promise.all([
            obtenerListaAdmin('ClienteServlet'),
            obtenerListaAdmin('PresupuestoServlet'),
            obtenerListaAdmin('InsumoServlet'),
            obtenerListaAdmin('ProductoServlet'),
            obtenerListaAdmin('ProductoServlet?accion=masVendidos')
        ]);

        document.getElementById('metric-clientes').textContent = String(clientes.length);
        const totalPresupuestos = presupuestos.reduce(
            (total, presupuesto) => total + (Number(presupuesto.total) || 0),
            0
        );
        document.getElementById('metric-ventas').textContent = totalPresupuestos.toLocaleString('es-AR', {
            style: 'currency',
            currency: 'ARS'
        });
        const insumosCriticos = insumos.filter(
            insumo => Number(insumo.stockActual) <= Number(insumo.stockMinimo)
        ).length;
        document.getElementById('metric-insumos').textContent = String(insumosCriticos);

        const tbody = document.querySelector('#tabla-top-productos tbody');
        tbody.innerHTML = productos.length
            ? productos.map(producto => `
                <tr>
                    <td>${escaparHTML(producto.codigo)}</td>
                    <td>${escaparHTML(producto.nombre)}</td>
                    <td>${Number(producto.stockDisponible) || 0}</td>
                </tr>
            `).join('')
            : '<tr><td colspan="3">Todavía no hay productos registrados.</td></tr>';

        const vendidosTbody = document.querySelector('#tabla-mas-vendidos tbody');
        vendidosTbody.innerHTML = masVendidos.length
            ? masVendidos.map(producto => `
                <tr>
                    <td>${escaparHTML(producto.codigo)}</td>
                    <td>${escaparHTML(producto.nombre)}</td>
                    <td>${Number(producto.totalVendido) || 0}</td>
                </tr>
            `).join('')
            : '<tr><td colspan="3">Todavía no hay compras registradas.</td></tr>';

        const insumosTbody = document.querySelector('#tabla-insumos-admin tbody');
        insumosTbody.innerHTML = insumos.length
            ? insumos.map(insumo => `
                <tr>
                    <td>${escaparHTML(insumo.nombre)}</td>
                    <td>${Number(insumo.stockActual) || 0}</td>
                    <td>${Number(insumo.stockMinimo) || 0}</td>
                    <td>${escaparHTML(insumo.unidadMedida)}</td>
                </tr>
            `).join('')
            : '<tr><td colspan="4">No hay insumos registrados.</td></tr>';

        const selectorInsumo = document.getElementById('select-stock-insumo');
        const insumoSeleccionado = selectorInsumo.value;
        selectorInsumo.innerHTML = '<option value="">Seleccioná un insumo</option>' + insumos.map(insumo => `
            <option value="${Number(insumo.idInsumo)}">${escaparHTML(insumo.codigo)} - ${escaparHTML(insumo.nombre)}</option>
        `).join('');
        if (insumos.some(insumo => String(insumo.idInsumo) === insumoSeleccionado)) {
            selectorInsumo.value = insumoSeleccionado;
        }

        const alerta = document.getElementById('admin-alert');
        if (alerta) alerta.className = 'alert hidden';
    } catch (error) {
        console.error('Error al cargar el panel de administración:', error);
        mostrarMensajeAdmin(`No se pudieron cargar los datos del panel: ${error.message}`);
    }
}

async function reponerStockInsumo(event) {
    event.preventDefault();
    const idInsumo = Number(document.getElementById('select-stock-insumo').value);
    const cantidad = Number(document.getElementById('input-stock-cantidad').value);
    if (!Number.isInteger(idInsumo) || idInsumo < 1 || !Number.isFinite(cantidad) || cantidad <= 0) {
        mostrarMensajeStock('Seleccioná un insumo e ingresá una cantidad positiva.');
        return;
    }

    try {
        const respuesta = await fetch(`${API_BASE}/InsumoServlet?accion=reponer`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ idInsumo, stockActual: cantidad })
        });
        const resultado = await respuesta.json();
        if (!respuesta.ok || resultado.status !== 'OK') {
            throw new Error(resultado.message || 'No se pudo actualizar el stock.');
        }
        document.getElementById('form-reponer-stock').reset();
        await cargarDashboardAdmin();
        mostrarMensajeStock('Stock de insumo actualizado correctamente.', 'success');
    } catch (error) {
        console.error('Error al reponer insumo:', error);
        mostrarMensajeStock('No se pudo reponer el insumo. Revisá la conexión e intentá nuevamente.');
    }
}

function mostrarMensajeStock(mensaje, tipo = 'danger') {
    const alerta = document.getElementById('stock-alert');
    alerta.textContent = mensaje;
    alerta.className = `alert alert-${tipo}`;
}

async function ejecutarBorradoGlobalAdmin() {
    const selector = document.getElementById('select-entidad-borrado');
    const campoId = document.getElementById('input-id-borrado');
    const servlet = SERVLETS_ADMIN[selector.value];
    const id = Number(campoId.value);

    if (!servlet || !Number.isInteger(id) || id < 1) {
        mostrarMensajeAdmin('Seleccioná una entidad e ingresá un ID válido.');
        return;
    }

    if (!confirm(`¿Estás seguro de desactivar el registro ID ${id} de ${selector.value}?`)) {
        return;
    }

    try {
        const respuesta = await fetch(`${API_BASE}/${servlet}?id=${id}&fisico=false`, {
            method: 'DELETE'
        });
        if (!respuesta.ok) {
            throw new Error(`Error del servidor (${respuesta.status})`);
        }

        const resultado = await respuesta.json();
        if (resultado.status !== 'OK') {
            mostrarMensajeAdmin('No se pudo desactivar el registro. Verificá que el ID exista.');
            return;
        }

        campoId.value = '';
        await cargarDashboardAdmin();
        mostrarMensajeAdmin('Registro desactivado correctamente.', 'success');
    } catch (error) {
        console.error('Error al desactivar el registro:', error);
        mostrarMensajeAdmin('No se pudo completar la operación. Revisá la conexión e intentá nuevamente.');
    }
}
