function escaparCliente(valor) {
    const elemento = document.createElement('span');
    elemento.textContent = valor == null ? '' : String(valor);
    return elemento.innerHTML;
}

async function cargarClientesAdmin() {
    const tbody = document.getElementById('tbody-clientes');
    try {
        const respuesta = await fetch(`${API_BASE}/ClienteServlet`);
        if (!respuesta.ok) {
            throw new Error(`ClienteServlet respondió con error HTTP ${respuesta.status}.`);
        }
        let clientes;
        try {
            clientes = await respuesta.json();
        } catch {
            throw new Error('ClienteServlet no devolvió JSON válido; revisá la sesión y el registro del servidor.');
        }
        if (!Array.isArray(clientes)) {
            throw new Error('ClienteServlet no devolvió una lista de clientes.');
        }
        tbody.innerHTML = clientes.length
            ? clientes.map(cliente => `
                <tr>
                    <td>${Number(cliente.idCliente) || ''}</td>
                    <td>${escaparCliente(`${cliente.nombre || ''} ${cliente.apellido || ''}`.trim())}</td>
                    <td>${escaparCliente(cliente.dni)}</td>
                    <td>${escaparCliente(cliente.telefono)}</td>
                    <td>${escaparCliente(cliente.email)}</td>
                </tr>
            `).join('')
            : '<tr><td colspan="6">Todavía no hay clientes registrados.</td></tr>';
    } catch (error) {
        console.error('Error al cargar clientes:', error);
        const alerta = document.getElementById('clientes-alert');
        alerta.textContent = `No se pudo cargar el listado de clientes: ${error.message}`;
        alerta.className = 'alert alert-danger';
    }
}
