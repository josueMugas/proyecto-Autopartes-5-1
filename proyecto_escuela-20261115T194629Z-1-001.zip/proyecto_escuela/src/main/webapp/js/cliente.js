async function cargarDatosCliente() {
    try {
        const respuesta = await fetch(`${API_BASE}/AuthServlet`);
        if (!respuesta.ok) {
            throw new Error(`No se pudo consultar la cuenta (${respuesta.status})`);
        }
        const cuenta = await respuesta.json();
        if (cuenta.error || cuenta.saldo == null) {
            throw new Error(cuenta.error || 'La cuenta no tiene un cliente asociado');
        }
        document.getElementById('lbl-saldo').textContent = Number(cuenta.saldo).toLocaleString('es-AR', {
            style: 'currency',
            currency: 'ARS'
        });
    } catch (error) {
        console.error('Error al cargar el saldo:', error);
        alert('No se pudo cargar el saldo de la cuenta.');
    }

    try {
        const respuesta = await fetch(`${API_BASE}/ProductoServlet`);
        if (!respuesta.ok) {
            throw new Error(`No se pudieron cargar los productos (${respuesta.status})`);
        }
        const productos = await respuesta.json();
        renderizarCatalogo(productos);
    } catch (error) {
        console.error('Error al cargar productos:', error);
        alert('No se pudo cargar el catálogo de productos.');
    }
}

function renderizarCatalogo(productos) {
    window.productosCatalogo = productos;
    const contenedor = document.getElementById('catalogo-productos');
    contenedor.innerHTML = productos.length
        ? productos.map(producto => {
            const stock = Number(producto.stockDisponible) || 0;
            const precioDisponible = Number(producto.precioVenta) > 0;
            const textoBoton = stock < 1 ? 'Sin stock' : precioDisponible ? 'Añadir al carrito' : 'Precio pendiente';
            const textoPrecio = precioDisponible ? formatearMoneda(producto.precioVenta) : 'Pendiente de administración';
            return `
            <article class="card-producto">
                <h4>${escaparTexto(producto.nombre)}</h4>
                <p>Código: ${escaparTexto(producto.codigo)}</p>
                <p>Precio: <strong>${textoPrecio}</strong></p>
                <p>Stock disponible: <strong>${stock}</strong></p>
                <button type="button" class="btn-primary"
                    onclick="agregarAlCarrito(${Number(producto.idProducto)})"
                    ${stock < 1 || !precioDisponible ? 'disabled' : ''}>
                    ${textoBoton}
                </button>
            </article>
            `;
        }).join('')
        : '<p>No hay productos disponibles.</p>';
}

function formatearMoneda(valor) {
    return Number(valor || 0).toLocaleString('es-AR', { style: 'currency', currency: 'ARS' });
}

function escaparTexto(valor) {
    const elemento = document.createElement('span');
    elemento.textContent = valor == null ? '' : String(valor);
    return elemento.innerHTML;
}

async function abrirModalCargaSaldo() {
    const entrada = prompt('Ingresá el monto a cargar en tu cuenta:');
    if (entrada === null) return;
    const monto = Number(entrada);
    if (!Number.isFinite(monto) || monto <= 0) {
        alert('Ingresá un monto válido mayor a cero.');
        return;
    }

    try {
        const respuesta = await fetch(`${API_BASE}/AuthServlet?action=cargarSaldo`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ monto })
        });
        const resultado = await respuesta.json();
        if (!respuesta.ok || resultado.status !== 'OK') {
            alert(resultado.message || 'No se pudo cargar el saldo.');
            return;
        }
        document.getElementById('lbl-saldo').textContent = Number(resultado.saldo).toLocaleString('es-AR', {
            style: 'currency',
            currency: 'ARS'
        });
        alert('Saldo cargado correctamente.');
    } catch (error) {
        console.error('Error al cargar saldo:', error);
        alert('No se pudo cargar el saldo. Revisá la conexión e intentá nuevamente.');
    }
}
