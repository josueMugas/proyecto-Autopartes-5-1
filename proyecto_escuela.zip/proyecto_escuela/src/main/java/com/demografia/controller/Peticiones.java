package com.demografia.controller;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Map;

/**
 * Utilidades compartidas por los servlets para validar la entrada
 * y responder 400 en lugar de lanzar excepciones.
 */
final class Peticiones {

    private Peticiones() {
    }

    /** Convierte un parámetro a entero; devuelve null si falta o no es numérico. */
    static Integer id(String valor) {
        if (valor == null) {
            return null;
        }
        try {
            return Integer.valueOf(valor.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /**
     * Id del recurso para PUT/PATCH: primero el parámetro ?id=, si no viene
     * se usa el campo indicado del cuerpo JSON. Devuelve null si no es válido.
     */
    static Integer idRecurso(HttpServletRequest req, JsonObject cuerpo, String campoId) {
        Integer id = id(req.getParameter("id"));
        if (id == null && cuerpo != null && cuerpo.has(campoId)) {
            try {
                id = cuerpo.get(campoId).getAsInt();
            } catch (RuntimeException e) {
                return null;
            }
        }
        return (id == null || id < 1) ? null : id;
    }

    /** Lee el cuerpo JSON; devuelve null si está vacío o mal formado. */
    static <T> T leerCuerpo(HttpServletRequest req, Gson gson, Class<T> tipo) throws IOException {
        try {
            return gson.fromJson(req.getReader(), tipo);
        } catch (JsonParseException e) {
            return null;
        }
    }

    /** Lee el cuerpo como objeto JSON genérico; null si está vacío, mal formado o no es un objeto. */
    static JsonObject leerObjeto(HttpServletRequest req) throws IOException {
        try {
            JsonElement elemento = JsonParser.parseReader(req.getReader());
            return elemento != null && elemento.isJsonObject() ? elemento.getAsJsonObject() : null;
        } catch (JsonParseException | IllegalStateException e) {
            return null;
        }
    }

    /** Convierte el objeto JSON al modelo; null si algún campo tiene un tipo inválido. */
    static <T> T convertir(Gson gson, JsonObject cuerpo, Class<T> tipo) {
        try {
            return gson.fromJson(cuerpo, tipo);
        } catch (JsonParseException | NumberFormatException e) {
            return null;
        }
    }

    /**
     * Aplica sobre {@code destino} solo los campos presentes en {@code cambios}
     * (semántica de PATCH). Los campos desconocidos se ignoran.
     *
     * @return false si algún valor no tiene el tipo esperado.
     */
    static boolean aplicarCambios(Gson gson, Object destino, JsonObject cambios) {
        for (Map.Entry<String, JsonElement> cambio : cambios.entrySet()) {
            Field campo = buscarCampo(destino.getClass(), cambio.getKey());
            if (campo == null) {
                continue;
            }
            try {
                Object valor = gson.fromJson(cambio.getValue(), campo.getGenericType());
                if (valor == null && campo.getType().isPrimitive()) {
                    return false;
                }
                campo.setAccessible(true);
                campo.set(destino, valor);
            } catch (JsonParseException | NumberFormatException | IllegalAccessException e) {
                return false;
            }
        }
        return true;
    }

    private static Field buscarCampo(Class<?> tipo, String nombre) {
        for (Class<?> c = tipo; c != null && c != Object.class; c = c.getSuperclass()) {
            try {
                Field campo = c.getDeclaredField(nombre);
                return Modifier.isStatic(campo.getModifiers()) ? null : campo;
            } catch (NoSuchFieldException e) {
                // seguir buscando en la superclase
            }
        }
        return null;
    }

    static void responderResultado(HttpServletResponse resp, boolean ok) throws IOException {
        resp.getWriter().write("{\"status\":\"" + (ok ? "OK" : "ERROR") + "\"}");
    }

    static void solicitudInvalida(HttpServletResponse resp, String mensaje) throws IOException {
        error(resp, HttpServletResponse.SC_BAD_REQUEST, mensaje);
    }

    static void noEncontrado(HttpServletResponse resp, String mensaje) throws IOException {
        error(resp, HttpServletResponse.SC_NOT_FOUND, mensaje);
    }

    static void metodoNoPermitido(HttpServletResponse resp, String mensaje) throws IOException {
        error(resp, HttpServletResponse.SC_METHOD_NOT_ALLOWED, mensaje);
    }

    private static void error(HttpServletResponse resp, int estado, String mensaje) throws IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.setStatus(estado);
        resp.getWriter().write("{\"status\":\"ERROR\",\"message\":\"" + mensaje + "\"}");
    }
}
