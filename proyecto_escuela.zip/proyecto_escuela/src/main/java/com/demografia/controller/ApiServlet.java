package com.demografia.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet base de la API.
 *
 * HttpServlet trae doGet, doPost, doPut y doDelete, pero no doPatch:
 * su método service() responde 405 a cualquier PATCH. Esta clase
 * intercepta el verbo PATCH y lo deriva a doPatch(), para que cada
 * servlet pueda implementarlo igual que los demás verbos.
 *
 *  - PUT   reemplaza el recurso completo (se envían todos los campos).
 *  - PATCH modifica solo los campos enviados en el cuerpo JSON.
 */
public abstract class ApiServlet extends HttpServlet {

    private static final String METODO_PATCH = "PATCH";

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        if (METODO_PATCH.equalsIgnoreCase(req.getMethod())) {
            doPatch(req, resp);
        } else {
            super.service(req, resp);
        }
    }

    /** Por defecto un recurso no admite PATCH: responde 405. */
    protected void doPatch(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        Peticiones.metodoNoPermitido(resp, "Este recurso no admite PATCH.");
    }
}
