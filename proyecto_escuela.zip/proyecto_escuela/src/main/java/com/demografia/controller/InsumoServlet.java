package com.demografia.controller;

import com.demografia.dao.IInsumoDAO;
import com.demografia.dao.FactoryDAO;
import com.demografia.modelo.Insumo;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/InsumoServlet")
public class InsumoServlet extends ApiServlet {
    
    private final IInsumoDAO insumoDAO = FactoryDAO.getInsumoDAO();
    private final Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        
        String idParam = req.getParameter("id");
        if (idParam != null) {
            Integer id = Peticiones.id(idParam);
            if (id == null) {
                Peticiones.solicitudInvalida(resp, "El id debe ser numérico");
                return;
            }
            resp.getWriter().write(gson.toJson(insumoDAO.listById(id)));
        } else {
            resp.getWriter().write(gson.toJson(insumoDAO.listAll()));
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        
        Insumo i = Peticiones.leerCuerpo(req, gson, Insumo.class);
        if ("reponer".equals(req.getParameter("accion"))) {
            if (i == null || i.getIdInsumo() < 1 || i.getStockActual() == null
                    || i.getStockActual().signum() <= 0) {
                resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Seleccioná un insumo e ingresá una cantidad positiva.");
                return;
            }
            boolean ok = insumoDAO.reponerStock(i.getIdInsumo(), i.getStockActual());
            resp.getWriter().write("{\"status\":\"" + (ok ? "OK" : "ERROR") + "\"}");
            return;
        }
        if (i == null) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Los datos del insumo no son válidos.");
            return;
        }
        boolean ok = (i.getIdInsumo() > 0) ? insumoDAO.update(i) : insumoDAO.insert(i);
        resp.getWriter().write("{\"status\":\"" + (ok ? "OK" : "ERROR") + "\"}");
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        Integer id = Peticiones.id(req.getParameter("id"));
        if (id == null) {
            Peticiones.solicitudInvalida(resp, "Falta el id o no es numérico");
            return;
        }
        boolean esFisico = Boolean.parseBoolean(req.getParameter("fisico"));

        boolean ok = esFisico ? insumoDAO.deleteFisico(id) : insumoDAO.delete(id);
        resp.getWriter().write("{\"status\":\"" + (ok ? "OK" : "ERROR") + "\"}");
    }

    /**
     * PUT: reemplaza el insumo completo. El id va en ?id= o en el cuerpo ("idInsumo").
     * Responde 400 si faltan datos y 404 si el registro no existe.
     */
    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        JsonObject cuerpo = Peticiones.leerObjeto(req);
        if (cuerpo == null) {
            Peticiones.solicitudInvalida(resp, "El cuerpo de la solicitud no es válido");
            return;
        }
        Integer id = Peticiones.idRecurso(req, cuerpo, "idInsumo");
        if (id == null) {
            Peticiones.solicitudInvalida(resp, "Falta el id o no es numérico");
            return;
        }
        if (insumoDAO.listById(id) == null) {
            Peticiones.noEncontrado(resp, "No existe el insumo con id " + id);
            return;
        }
        Insumo c = Peticiones.convertir(gson, cuerpo, Insumo.class);
        if (c == null || c.getCodigo() == null || c.getCodigo().trim().isEmpty() || c.getNombre() == null || c.getNombre().trim().isEmpty() || c.getStockActual() == null || c.getStockActual().signum() < 0 || c.getStockMinimo() == null || c.getStockMinimo().signum() < 0) {
            Peticiones.solicitudInvalida(resp, "Completá código, nombre y stocks (no negativos) del insumo.");
            return;
        }
        c.setIdInsumo(id);
        Peticiones.responderResultado(resp, insumoDAO.update(c));
    }

    /**
     * PATCH: modifica solo los campos enviados en el cuerpo JSON;
     * el resto conserva el valor guardado en la base de datos.
     */
    @Override
    protected void doPatch(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        JsonObject cuerpo = Peticiones.leerObjeto(req);
        if (cuerpo == null || cuerpo.size() == 0) {
            Peticiones.solicitudInvalida(resp, "Enviá al menos un campo a modificar");
            return;
        }
        Integer id = Peticiones.idRecurso(req, cuerpo, "idInsumo");
        if (id == null) {
            Peticiones.solicitudInvalida(resp, "Falta el id o no es numérico");
            return;
        }
        Insumo c = insumoDAO.listById(id);
        if (c == null) {
            Peticiones.noEncontrado(resp, "No existe el insumo con id " + id);
            return;
        }
        if (!Peticiones.aplicarCambios(gson, c, cuerpo)) {
            Peticiones.solicitudInvalida(resp, "Algún campo tiene un valor inválido");
            return;
        }
        c.setIdInsumo(id);
        if (c.getCodigo() == null || c.getCodigo().trim().isEmpty() || c.getNombre() == null || c.getNombre().trim().isEmpty() || c.getStockActual() == null || c.getStockActual().signum() < 0 || c.getStockMinimo() == null || c.getStockMinimo().signum() < 0) {
            Peticiones.solicitudInvalida(resp, "Completá código, nombre y stocks (no negativos) del insumo.");
            return;
        }
        Peticiones.responderResultado(resp, insumoDAO.update(c));
    }
}
