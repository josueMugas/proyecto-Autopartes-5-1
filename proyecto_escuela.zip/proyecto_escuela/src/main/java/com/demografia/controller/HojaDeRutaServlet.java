package com.demografia.controller;

import com.demografia.dao.IHojaDeRutaDAO;
import com.demografia.dao.FactoryDAO;   
import com.demografia.modelo.HojaDeRuta;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/HojaDeRutaServlet")
public class HojaDeRutaServlet extends ApiServlet {
    
    private final IHojaDeRutaDAO hojaDAO = FactoryDAO.getHojaDeRutaDAO();
    private final Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        
        String idParam = req.getParameter("id");
        if (idParam != null) {
            Integer id = Peticiones.id(idParam);
            if (id == null) {
                Peticiones.solicitudInvalida(resp, "El id debe ser numérico");
                return;
            }
            resp.getWriter().write(gson.toJson(hojaDAO.listById(id)));
        } else {
            resp.getWriter().write(gson.toJson(hojaDAO.listAll()));
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        
        HojaDeRuta hr = Peticiones.leerCuerpo(req, gson, HojaDeRuta.class);
        if (hr == null) {
            Peticiones.solicitudInvalida(resp, "El cuerpo de la solicitud no es válido");
            return;
        }
        boolean ok = (hr.getIdHojaRuta() > 0) ? hojaDAO.update(hr) : hojaDAO.insert(hr);
        resp.getWriter().write("{\"status\":\"" + (ok ? "OK" : "ERROR") + "\"}");
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        Integer id = Peticiones.id(req.getParameter("id"));
        if (id == null) {
            Peticiones.solicitudInvalida(resp, "Falta el id o no es numérico");
            return;
        }
        boolean ok = hojaDAO.delete(id);
        resp.getWriter().write("{\"status\":\"" + (ok ? "OK" : "ERROR") + "\"}");
    }

    /**
     * PUT: reemplaza la hoja de ruta completo. El id va en ?id= o en el cuerpo ("idHojaRuta").
     * Responde 400 si faltan datos y 404 si el registro no existe.
     */
    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        JsonObject cuerpo = Peticiones.leerObjeto(req);
        if (cuerpo == null) {
            Peticiones.solicitudInvalida(resp, "El cuerpo de la solicitud no es válido");
            return;
        }
        Integer id = Peticiones.idRecurso(req, cuerpo, "idHojaRuta");
        if (id == null) {
            Peticiones.solicitudInvalida(resp, "Falta el id o no es numérico");
            return;
        }
        if (hojaDAO.listById(id) == null) {
            Peticiones.noEncontrado(resp, "No existe la hoja de ruta con id " + id);
            return;
        }
        HojaDeRuta c = Peticiones.convertir(gson, cuerpo, HojaDeRuta.class);
        if (c == null || c.getCodigoInalterable() == null || c.getCodigoInalterable().trim().isEmpty() || c.getCantidad() < 1) {
            Peticiones.solicitudInvalida(resp, "Completá el código y una cantidad positiva.");
            return;
        }
        c.setIdHojaRuta(id);
        Peticiones.responderResultado(resp, hojaDAO.update(c));
    }

    /**
     * PATCH: modifica solo los campos enviados en el cuerpo JSON;
     * el resto conserva el valor guardado en la base de datos.
     */
    @Override
    protected void doPatch(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        JsonObject cuerpo = Peticiones.leerObjeto(req);
        if (cuerpo == null || cuerpo.size() == 0) {
            Peticiones.solicitudInvalida(resp, "Enviá al menos un campo a modificar");
            return;
        }
        Integer id = Peticiones.idRecurso(req, cuerpo, "idHojaRuta");
        if (id == null) {
            Peticiones.solicitudInvalida(resp, "Falta el id o no es numérico");
            return;
        }
        HojaDeRuta c = hojaDAO.listById(id);
        if (c == null) {
            Peticiones.noEncontrado(resp, "No existe la hoja de ruta con id " + id);
            return;
        }
        if (!Peticiones.aplicarCambios(gson, c, cuerpo)) {
            Peticiones.solicitudInvalida(resp, "Algún campo tiene un valor inválido");
            return;
        }
        c.setIdHojaRuta(id);
        if (c.getCodigoInalterable() == null || c.getCodigoInalterable().trim().isEmpty() || c.getCantidad() < 1) {
            Peticiones.solicitudInvalida(resp, "Completá el código y una cantidad positiva.");
            return;
        }
        Peticiones.responderResultado(resp, hojaDAO.update(c));
    }
}
