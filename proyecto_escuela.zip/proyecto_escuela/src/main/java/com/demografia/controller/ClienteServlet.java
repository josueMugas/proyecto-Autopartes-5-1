package com.demografia.controller;

import com.demografia.dao.IClienteDAO;
import com.demografia.dao.FactoryDAO;
import com.demografia.modelo.Cliente;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/ClienteServlet")
public class ClienteServlet extends ApiServlet {
    
    // Aplicación estricta del Patrón Factory
    private final IClienteDAO clienteDAO = FactoryDAO.getClienteDAO();
    private final Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        
        String idParam = req.getParameter("id");
        if (idParam != null) {
            Integer id = Peticiones.id(idParam);
            if (id == null) {
                Peticiones.solicitudInvalida(resp, "El id debe ser numérico");
                return;
            }
            resp.getWriter().write(gson.toJson(clienteDAO.listById(id)));
        } else {
            resp.getWriter().write(gson.toJson(clienteDAO.listAll()));
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        
        Cliente c = Peticiones.leerCuerpo(req, gson, Cliente.class);
        if (c == null) {
            Peticiones.solicitudInvalida(resp, "El cuerpo de la solicitud no es válido");
            return;
        }
        boolean ok = (c.getIdCliente() > 0) ? clienteDAO.update(c) : clienteDAO.insert(c);
        resp.getWriter().write("{\"status\":\"" + (ok ? "OK" : "ERROR") + "\"}");
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        Integer id = Peticiones.id(req.getParameter("id"));
        if (id == null) {
            Peticiones.solicitudInvalida(resp, "Falta el id o no es numérico");
            return;
        }
        boolean esFisico = Boolean.parseBoolean(req.getParameter("fisico"));

        boolean ok = esFisico ? clienteDAO.deleteFisico(id) : clienteDAO.delete(id);
        resp.getWriter().write("{\"status\":\"" + (ok ? "OK" : "ERROR") + "\"}");
    }

    /**
     * PUT: reemplaza el cliente completo. El id va en ?id= o en el cuerpo ("idCliente").
     * Responde 400 si faltan datos y 404 si el registro no existe.
     */
    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        JsonObject cuerpo = Peticiones.leerObjeto(req);
        if (cuerpo == null) {
            Peticiones.solicitudInvalida(resp, "El cuerpo de la solicitud no es válido");
            return;
        }
        Integer id = Peticiones.idRecurso(req, cuerpo, "idCliente");
        if (id == null) {
            Peticiones.solicitudInvalida(resp, "Falta el id o no es numérico");
            return;
        }
        if (clienteDAO.listById(id) == null) {
            Peticiones.noEncontrado(resp, "No existe el cliente con id " + id);
            return;
        }
        Cliente c = Peticiones.convertir(gson, cuerpo, Cliente.class);
        if (c == null || c.getNombre() == null || c.getNombre().trim().isEmpty() || c.getApellido() == null || c.getApellido().trim().isEmpty()) {
            Peticiones.solicitudInvalida(resp, "Completá nombre y apellido del cliente.");
            return;
        }
        c.setIdCliente(id);
        Peticiones.responderResultado(resp, clienteDAO.update(c));
    }

    /**
     * PATCH: modifica solo los campos enviados en el cuerpo JSON;
     * el resto conserva el valor guardado en la base de datos.
     */
    @Override
    protected void doPatch(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        JsonObject cuerpo = Peticiones.leerObjeto(req);
        if (cuerpo == null || cuerpo.size() == 0) {
            Peticiones.solicitudInvalida(resp, "Enviá al menos un campo a modificar");
            return;
        }
        Integer id = Peticiones.idRecurso(req, cuerpo, "idCliente");
        if (id == null) {
            Peticiones.solicitudInvalida(resp, "Falta el id o no es numérico");
            return;
        }
        Cliente c = clienteDAO.listById(id);
        if (c == null) {
            Peticiones.noEncontrado(resp, "No existe el cliente con id " + id);
            return;
        }
        if (!Peticiones.aplicarCambios(gson, c, cuerpo)) {
            Peticiones.solicitudInvalida(resp, "Algún campo tiene un valor inválido");
            return;
        }
        c.setIdCliente(id);
        if (c.getNombre() == null || c.getNombre().trim().isEmpty() || c.getApellido() == null || c.getApellido().trim().isEmpty()) {
            Peticiones.solicitudInvalida(resp, "Completá nombre y apellido del cliente.");
            return;
        }
        Peticiones.responderResultado(resp, clienteDAO.update(c));
    }
}
