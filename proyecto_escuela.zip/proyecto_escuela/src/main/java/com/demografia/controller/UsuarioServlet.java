package com.demografia.controller;

import com.demografia.dao.IUsuarioDAO;
import com.demografia.dao.FactoryDAO;
import com.demografia.modelo.Usuario;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import org.mindrot.jbcrypt.BCrypt;

@WebServlet("/UsuarioServlet")
public class UsuarioServlet extends ApiServlet {
    
    private final IUsuarioDAO usuarioDAO = FactoryDAO.getUsuarioDAO();
    private final Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        
        String idParam = req.getParameter("id");
        if (idParam != null) {
            Integer id = Peticiones.id(idParam);
            if (id == null) {
                Peticiones.solicitudInvalida(resp, "El id debe ser numérico");
                return;
            }
            resp.getWriter().write(gson.toJson(usuarioDAO.listById(id)));
        } else {
            resp.getWriter().write(gson.toJson(usuarioDAO.listAll()));
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        
        Usuario u = Peticiones.leerCuerpo(req, gson, Usuario.class);
        if (u == null) {
            Peticiones.solicitudInvalida(resp, "El cuerpo de la solicitud no es válido");
            return;
        }
        boolean ok = (u.getIdUsuario() > 0) ? usuarioDAO.update(u) : usuarioDAO.insert(u);
        resp.getWriter().write("{\"status\":\"" + (ok ? "OK" : "ERROR") + "\"}");
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        Integer id = Peticiones.id(req.getParameter("id"));
        if (id == null) {
            Peticiones.solicitudInvalida(resp, "Falta el id o no es numérico");
            return;
        }
        boolean esFisico = Boolean.parseBoolean(req.getParameter("fisico"));

        boolean ok = esFisico ? usuarioDAO.deleteFisico(id) : usuarioDAO.delete(id);
        resp.getWriter().write("{\"status\":\"" + (ok ? "OK" : "ERROR") + "\"}");
    }

    /**
     * PUT: reemplaza el usuario completo. El id va en ?id= o en el cuerpo ("idUsuario").
     * Responde 400 si faltan datos y 404 si el registro no existe.
     */
    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        JsonObject cuerpo = Peticiones.leerObjeto(req);
        if (cuerpo == null) {
            Peticiones.solicitudInvalida(resp, "El cuerpo de la solicitud no es válido");
            return;
        }
        Integer id = Peticiones.idRecurso(req, cuerpo, "idUsuario");
        if (id == null) {
            Peticiones.solicitudInvalida(resp, "Falta el id o no es numérico");
            return;
        }
        if (usuarioDAO.listById(id) == null) {
            Peticiones.noEncontrado(resp, "No existe el usuario con id " + id);
            return;
        }
        Usuario c = Peticiones.convertir(gson, cuerpo, Usuario.class);
        if (c == null || c.getNombreUsuario() == null || c.getNombreUsuario().trim().isEmpty() || c.getClave() == null || c.getClave().trim().isEmpty()) {
            Peticiones.solicitudInvalida(resp, "Completá nombre de usuario y clave.");
            return;
        }
        c.setIdUsuario(id);
        protegerClave(c);
        Peticiones.responderResultado(resp, usuarioDAO.update(c));
    }

    /**
     * PATCH: modifica solo los campos enviados en el cuerpo JSON;
     * el resto conserva el valor guardado en la base de datos.
     */
    @Override
    protected void doPatch(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        JsonObject cuerpo = Peticiones.leerObjeto(req);
        if (cuerpo == null || cuerpo.size() == 0) {
            Peticiones.solicitudInvalida(resp, "Enviá al menos un campo a modificar");
            return;
        }
        Integer id = Peticiones.idRecurso(req, cuerpo, "idUsuario");
        if (id == null) {
            Peticiones.solicitudInvalida(resp, "Falta el id o no es numérico");
            return;
        }
        Usuario c = usuarioDAO.listById(id);
        if (c == null) {
            Peticiones.noEncontrado(resp, "No existe el usuario con id " + id);
            return;
        }
        if (!Peticiones.aplicarCambios(gson, c, cuerpo)) {
            Peticiones.solicitudInvalida(resp, "Algún campo tiene un valor inválido");
            return;
        }
        c.setIdUsuario(id);
        if (c.getNombreUsuario() == null || c.getNombreUsuario().trim().isEmpty() || c.getClave() == null || c.getClave().trim().isEmpty()) {
            Peticiones.solicitudInvalida(resp, "Completá nombre de usuario y clave.");
            return;
        }
        if (cuerpo.has("clave")) {
            protegerClave(c);
        }
        Peticiones.responderResultado(resp, usuarioDAO.update(c));
    }

    /** Guarda la clave hasheada con BCrypt (si todavía no lo está). */
    private static void protegerClave(Usuario u) {
        String clave = u.getClave();
        if (clave != null && !clave.startsWith("$2a$") && !clave.startsWith("$2b$")) {
            u.setClave(BCrypt.hashpw(clave, BCrypt.gensalt()));
        }
    }
}
