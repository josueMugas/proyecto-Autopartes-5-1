package com.demografia.controller;

import com.demografia.dao.IProductoDAO;
import com.demografia.dao.FactoryDAO;
import com.demografia.modelo.Producto;
import com.demografia.modelo.Usuario;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/ProductoServlet")
public class ProductoServlet extends ApiServlet {
    
    private final IProductoDAO productoDAO = FactoryDAO.getProductoDAO();
    private final Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        
        String idParam = req.getParameter("id");
        String accion = req.getParameter("accion");
        if ("masVendidos".equals(accion)) {
            if (!esAdministrador(req)) {
                resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Solo los administradores pueden consultar este informe.");
                return;
            }
            resp.getWriter().write(gson.toJson(productoDAO.listTopSold()));
        } else if (idParam != null) {
            Integer id = Peticiones.id(idParam);
            if (id == null) {
                Peticiones.solicitudInvalida(resp, "El id debe ser numérico");
                return;
            }
            resp.getWriter().write(gson.toJson(productoDAO.listById(id)));
        } else {
            resp.getWriter().write(gson.toJson(productoDAO.listAll()));
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        if (!esAdministrador(req)) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Solo los administradores pueden modificar productos.");
            return;
        }

        Producto p = Peticiones.leerCuerpo(req, gson, Producto.class);
        if (p == null || p.getCodigo() == null || p.getCodigo().trim().isEmpty()
                || p.getNombre() == null || p.getNombre().trim().isEmpty()
                || p.getPrecioVenta() == null || p.getPrecioVenta().signum() <= 0) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Completá los datos del producto y su precio.");
            return;
        }
        boolean ok = (p.getIdProducto() > 0) ? productoDAO.update(p) : productoDAO.insert(p);
        resp.getWriter().write("{\"status\":\"" + (ok ? "OK" : "ERROR") + "\"}");
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        if (!esAdministrador(req)) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Solo los administradores pueden modificar productos.");
            return;
        }
        Integer id = Peticiones.id(req.getParameter("id"));
        if (id == null) {
            Peticiones.solicitudInvalida(resp, "Falta el id o no es numérico");
            return;
        }
        boolean esFisico = Boolean.parseBoolean(req.getParameter("fisico"));

        boolean ok = esFisico ? productoDAO.deleteFisico(id) : productoDAO.delete(id);
        resp.getWriter().write("{\"status\":\"" + (ok ? "OK" : "ERROR") + "\"}");
    }

    /**
     * PUT: reemplaza el producto completo. El id va en ?id= o en el cuerpo ("idProducto").
     * Responde 400 si faltan datos y 404 si el registro no existe.
     */
    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        if (!esAdministrador(req)) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Solo los administradores pueden modificar productos.");
            return;
        }
        JsonObject cuerpo = Peticiones.leerObjeto(req);
        if (cuerpo == null) {
            Peticiones.solicitudInvalida(resp, "El cuerpo de la solicitud no es válido");
            return;
        }
        Integer id = Peticiones.idRecurso(req, cuerpo, "idProducto");
        if (id == null) {
            Peticiones.solicitudInvalida(resp, "Falta el id o no es numérico");
            return;
        }
        if (productoDAO.listById(id) == null) {
            Peticiones.noEncontrado(resp, "No existe el producto con id " + id);
            return;
        }
        Producto c = Peticiones.convertir(gson, cuerpo, Producto.class);
        if (c == null || c.getCodigo() == null || c.getCodigo().trim().isEmpty() || c.getNombre() == null || c.getNombre().trim().isEmpty() || c.getPrecioVenta() == null || c.getPrecioVenta().signum() <= 0) {
            Peticiones.solicitudInvalida(resp, "Completá los datos del producto y su precio.");
            return;
        }
        c.setIdProducto(id);
        Peticiones.responderResultado(resp, productoDAO.update(c));
    }

    /**
     * PATCH: modifica solo los campos enviados en el cuerpo JSON;
     * el resto conserva el valor guardado en la base de datos.
     */
    @Override
    protected void doPatch(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        if (!esAdministrador(req)) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Solo los administradores pueden modificar productos.");
            return;
        }
        JsonObject cuerpo = Peticiones.leerObjeto(req);
        if (cuerpo == null || cuerpo.size() == 0) {
            Peticiones.solicitudInvalida(resp, "Enviá al menos un campo a modificar");
            return;
        }
        Integer id = Peticiones.idRecurso(req, cuerpo, "idProducto");
        if (id == null) {
            Peticiones.solicitudInvalida(resp, "Falta el id o no es numérico");
            return;
        }
        Producto c = productoDAO.listById(id);
        if (c == null) {
            Peticiones.noEncontrado(resp, "No existe el producto con id " + id);
            return;
        }
        if (!Peticiones.aplicarCambios(gson, c, cuerpo)) {
            Peticiones.solicitudInvalida(resp, "Algún campo tiene un valor inválido");
            return;
        }
        c.setIdProducto(id);
        if (c.getCodigo() == null || c.getCodigo().trim().isEmpty() || c.getNombre() == null || c.getNombre().trim().isEmpty() || c.getPrecioVenta() == null || c.getPrecioVenta().signum() <= 0) {
            Peticiones.solicitudInvalida(resp, "Completá los datos del producto y su precio.");
            return;
        }
        Peticiones.responderResultado(resp, productoDAO.update(c));
    }

    private boolean esAdministrador(HttpServletRequest req) {
        HttpSession session = req.getSession(false);
        Object usuarioSesion = session == null ? null : session.getAttribute("usuarioLogueado");
        return usuarioSesion instanceof Usuario && ((Usuario) usuarioSesion).getIdRol() == 1;
    }
}