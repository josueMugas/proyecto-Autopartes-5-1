package com.demografia.controller;

import com.demografia.dao.IRolDAO;
import com.demografia.dao.FactoryDAO;
import com.demografia.modelo.Rol;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/RolServlet")
public class RolServlet extends ApiServlet {
    
    private final IRolDAO rolDAO = FactoryDAO.getRolDAO();
    private final Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        
        String idParam = req.getParameter("id");
        if (idParam != null) {
            Integer id = Peticiones.id(idParam);
            if (id == null) {
                Peticiones.solicitudInvalida(resp, "El id debe ser numérico");
                return;
            }
            resp.getWriter().write(gson.toJson(rolDAO.listById(id)));
        } else {
            resp.getWriter().write(gson.toJson(rolDAO.listAll()));
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        
        Rol r = Peticiones.leerCuerpo(req, gson, Rol.class);
        if (r == null) {
            Peticiones.solicitudInvalida(resp, "El cuerpo de la solicitud no es válido");
            return;
        }
        boolean ok = (r.getIdRol() > 0) ? rolDAO.update(r) : rolDAO.insert(r);
        resp.getWriter().write("{\"status\":\"" + (ok ? "OK" : "ERROR") + "\"}");
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        Integer id = Peticiones.id(req.getParameter("id"));
        if (id == null) {
            Peticiones.solicitudInvalida(resp, "Falta el id o no es numérico");
            return;
        }
        boolean ok = rolDAO.delete(id);
        resp.getWriter().write("{\"status\":\"" + (ok ? "OK" : "ERROR") + "\"}");
    }

    /**
     * PUT: reemplaza el rol completo. El id va en ?id= o en el cuerpo ("idRol").
     * Responde 400 si faltan datos y 404 si el registro no existe.
     */
    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        JsonObject cuerpo = Peticiones.leerObjeto(req);
        if (cuerpo == null) {
            Peticiones.solicitudInvalida(resp, "El cuerpo de la solicitud no es válido");
            return;
        }
        Integer id = Peticiones.idRecurso(req, cuerpo, "idRol");
        if (id == null) {
            Peticiones.solicitudInvalida(resp, "Falta el id o no es numérico");
            return;
        }
        if (rolDAO.listById(id) == null) {
            Peticiones.noEncontrado(resp, "No existe el rol con id " + id);
            return;
        }
        Rol c = Peticiones.convertir(gson, cuerpo, Rol.class);
        if (c == null || c.getNombreRol() == null || c.getNombreRol().trim().isEmpty()) {
            Peticiones.solicitudInvalida(resp, "Completá el nombre del rol.");
            return;
        }
        c.setIdRol(id);
        Peticiones.responderResultado(resp, rolDAO.update(c));
    }

    /**
     * PATCH: modifica solo los campos enviados en el cuerpo JSON;
     * el resto conserva el valor guardado en la base de datos.
     */
    @Override
    protected void doPatch(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        JsonObject cuerpo = Peticiones.leerObjeto(req);
        if (cuerpo == null || cuerpo.size() == 0) {
            Peticiones.solicitudInvalida(resp, "Enviá al menos un campo a modificar");
            return;
        }
        Integer id = Peticiones.idRecurso(req, cuerpo, "idRol");
        if (id == null) {
            Peticiones.solicitudInvalida(resp, "Falta el id o no es numérico");
            return;
        }
        Rol c = rolDAO.listById(id);
        if (c == null) {
            Peticiones.noEncontrado(resp, "No existe el rol con id " + id);
            return;
        }
        if (!Peticiones.aplicarCambios(gson, c, cuerpo)) {
            Peticiones.solicitudInvalida(resp, "Algún campo tiene un valor inválido");
            return;
        }
        c.setIdRol(id);
        if (c.getNombreRol() == null || c.getNombreRol().trim().isEmpty()) {
            Peticiones.solicitudInvalida(resp, "Completá el nombre del rol.");
            return;
        }
        Peticiones.responderResultado(resp, rolDAO.update(c));
    }
}
