package com.demografia.controller;

import com.demografia.dao.IPresupuestoDAO;
import com.demografia.dao.FactoryDAO;
import com.google.gson.Gson;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/PresupuestoServlet")
public class PresupuestoServlet extends ApiServlet {
    
    private final IPresupuestoDAO presupuestoDAO = FactoryDAO.getPresupuestoDAO();
    private final Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        
        String idParam = req.getParameter("id");
        if (idParam != null) {
            Integer id = Peticiones.id(idParam);
            if (id == null) {
                Peticiones.solicitudInvalida(resp, "El id debe ser numérico");
                return;
            }
            resp.getWriter().write(gson.toJson(presupuestoDAO.listById(id)));
        } else {
            resp.getWriter().write(gson.toJson(presupuestoDAO.listAll()));
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
        resp.getWriter().write("{\"status\":\"ERROR\",\"message\":\"Los presupuestos se crean al confirmar una compra.\"}");
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
        resp.getWriter().write("{\"status\":\"ERROR\",\"message\":\"No se pueden borrar presupuestos de compras confirmadas.\"}");
    }

    /** Un presupuesto de una compra confirmada no se modifica: PUT responde 405. */
    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Peticiones.metodoNoPermitido(resp, "Los presupuestos de una compra confirmada no se modifican.");
    }

    /** Un presupuesto de una compra confirmada no se modifica: PATCH responde 405. */
    @Override
    protected void doPatch(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Peticiones.metodoNoPermitido(resp, "Los presupuestos de una compra confirmada no se modifican.");
    }
}