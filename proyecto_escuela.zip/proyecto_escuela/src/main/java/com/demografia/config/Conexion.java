package com.demografia.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Conexión a la base de datos con el patrón Singleton.
 *
 *  - El constructor es privado: nadie puede hacer "new Conexion()".
 *  - Existe una única instancia, creada la primera vez que se pide
 *    con getInstance() (inicialización perezosa, thread-safe con
 *    doble verificación y "volatile", porque los servlets atienden
 *    varias peticiones en paralelo).
 *  - El driver JDBC y los datos de conexión se cargan una sola vez,
 *    en el constructor de esa única instancia.
 *
 * Cada DAO pide su Connection a la instancia y la cierra con
 * try-with-resources al terminar. No se comparte un único objeto
 * Connection entre hilos porque JDBC no lo garantiza como seguro y
 * un DAO que lo cierre dejaría sin conexión a los demás.
 */
public final class Conexion {

    private static final String URL = "jdbc:mysql://localhost:3307/demografia";
    private static final String USER = "root";
    private static final String PASS = "";

    /** Única instancia de la clase. */
    private static volatile Conexion instancia;

    private Conexion() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("No se encontró el controlador JDBC de MySQL.", e);
        }
    }

    /** Devuelve la única instancia de Conexion, creándola si todavía no existe. */
    public static Conexion getInstance() throws SQLException {
        Conexion resultado = instancia;
        if (resultado == null) {
            synchronized (Conexion.class) {
                resultado = instancia;
                if (resultado == null) {
                    instancia = resultado = new Conexion();
                }
            }
        }
        return resultado;
    }

    /** Abre una conexión a la base usando la configuración de la instancia única. */
    public Connection conectar() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    /**
     * Atajo usado por los DAO: equivale a Conexion.getInstance().conectar().
     * Se mantiene para no tener que modificar cada DAO.
     */
    public static Connection getConnection() throws SQLException {
        return getInstance().conectar();
    }
}
