package com.demografia.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.demografia.dao.FactoryDAO;
import com.demografia.dao.IClienteDAO;
import com.demografia.dao.IPresupuestoDAO;
import com.demografia.dao.IProductoDAO;
import com.demografia.dao.IUsuarioDAO;
import com.demografia.modelo.Cliente;
import com.demografia.modelo.Producto;
import com.demografia.modelo.Usuario;
import jakarta.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

/** Tests de los verbos PUT (reemplazo completo) y PATCH (modificación parcial). */
class PutPatchServletTest extends ServletTestBase {

    private IClienteDAO clienteDAO;
    private IProductoDAO productoDAO;
    private IUsuarioDAO usuarioDAO;

    @BeforeEach
    void preparar() {
        clienteDAO = mock(IClienteDAO.class);
        productoDAO = mock(IProductoDAO.class);
        usuarioDAO = mock(IUsuarioDAO.class);
        fabrica.when(FactoryDAO::getClienteDAO).thenReturn(clienteDAO);
        fabrica.when(FactoryDAO::getProductoDAO).thenReturn(productoDAO);
        fabrica.when(FactoryDAO::getUsuarioDAO).thenReturn(usuarioDAO);
        fabrica.when(FactoryDAO::getPresupuestoDAO).thenReturn(mock(IPresupuestoDAO.class));
    }

    private Cliente clienteGuardado() {
        Cliente c = new Cliente("Ana", "Pérez", "30111222", "1155550000", "ana@mail.com");
        c.setIdCliente(5);
        return c;
    }

    // ---------- VERDE ----------

    @Test
    void verde_put_reemplazaClienteCompleto() throws Exception {
        parametro("id", "5");
        cuerpo("{\"nombre\":\"Juan\",\"apellido\":\"Gómez\",\"dni\":\"1\",\"telefono\":\"2\",\"email\":\"j@m.com\"}");
        when(clienteDAO.listById(5)).thenReturn(clienteGuardado());
        when(clienteDAO.update(any())).thenReturn(true);

        new ClienteServlet().doPut(req, resp);

        ArgumentCaptor<Cliente> enviado = ArgumentCaptor.forClass(Cliente.class);
        verify(clienteDAO).update(enviado.capture());
        assertEquals(5, enviado.getValue().getIdCliente());
        assertEquals("Juan", enviado.getValue().getNombre());
        assertTrue(respuesta().contains("OK"));
    }

    @Test
    void verde_put_tomaElIdDelCuerpo() throws Exception {
        cuerpo("{\"idCliente\":5,\"nombre\":\"Juan\",\"apellido\":\"Gómez\"}");
        when(clienteDAO.listById(5)).thenReturn(clienteGuardado());
        when(clienteDAO.update(any())).thenReturn(true);

        new ClienteServlet().doPut(req, resp);

        verify(clienteDAO).update(any());
    }

    @Test
    void verde_patch_soloCambiaLosCamposEnviados() throws Exception {
        parametro("id", "5");
        cuerpo("{\"telefono\":\"1199998888\"}");
        when(clienteDAO.listById(5)).thenReturn(clienteGuardado());
        when(clienteDAO.update(any())).thenReturn(true);

        new ClienteServlet().doPatch(req, resp);

        ArgumentCaptor<Cliente> enviado = ArgumentCaptor.forClass(Cliente.class);
        verify(clienteDAO).update(enviado.capture());
        assertEquals("1199998888", enviado.getValue().getTelefono());
        assertEquals("Ana", enviado.getValue().getNombre());
        assertEquals("ana@mail.com", enviado.getValue().getEmail());
    }

    @Test
    void verde_patch_productoCambiaPrecioSiEsAdmin() throws Exception {
        sesionDe(usuario(1, 0));
        parametro("id", "3");
        cuerpo("{\"precioVenta\":2500.75}");
        Producto guardado = new Producto();
        guardado.setIdProducto(3);
        guardado.setCodigo("P-1");
        guardado.setNombre("Mesa");
        guardado.setPrecioVenta(new BigDecimal("1500"));
        when(productoDAO.listById(3)).thenReturn(guardado);
        when(productoDAO.update(any())).thenReturn(true);

        new ProductoServlet().doPatch(req, resp);

        ArgumentCaptor<Producto> enviado = ArgumentCaptor.forClass(Producto.class);
        verify(productoDAO).update(enviado.capture());
        assertEquals(new BigDecimal("2500.75"), enviado.getValue().getPrecioVenta());
        assertEquals("Mesa", enviado.getValue().getNombre());
    }

    @Test
    void verde_patch_usuarioHasheaLaClaveNueva() throws Exception {
        parametro("id", "7");
        cuerpo("{\"clave\":\"nueva123\"}");
        when(usuarioDAO.listById(7)).thenReturn(usuario(2, 0));
        when(usuarioDAO.update(any())).thenReturn(true);

        new UsuarioServlet().doPatch(req, resp);

        ArgumentCaptor<Usuario> enviado = ArgumentCaptor.forClass(Usuario.class);
        verify(usuarioDAO).update(enviado.capture());
        assertTrue(enviado.getValue().getClave().startsWith("$2a$"));
    }

    // ---------- ROJO ----------

    @Test
    void rojo_put_sinIdResponde400() throws Exception {
        cuerpo("{\"nombre\":\"Juan\",\"apellido\":\"Gómez\"}");
        new ClienteServlet().doPut(req, resp);
        verify(resp).setStatus(HttpServletResponse.SC_BAD_REQUEST);
        verify(clienteDAO, never()).update(any());
    }

    @Test
    void rojo_put_idInexistenteResponde404() throws Exception {
        parametro("id", "99");
        cuerpo("{\"nombre\":\"Juan\",\"apellido\":\"Gómez\"}");
        when(clienteDAO.listById(99)).thenReturn(null);
        new ClienteServlet().doPut(req, resp);
        verify(resp).setStatus(HttpServletResponse.SC_NOT_FOUND);
        verify(clienteDAO, never()).update(any());
    }

    @Test
    void rojo_put_datosIncompletosResponde400() throws Exception {
        parametro("id", "5");
        cuerpo("{\"telefono\":\"123\"}");
        when(clienteDAO.listById(5)).thenReturn(clienteGuardado());
        new ClienteServlet().doPut(req, resp);
        verify(resp).setStatus(HttpServletResponse.SC_BAD_REQUEST);
        verify(clienteDAO, never()).update(any());
    }

    @Test
    void rojo_patch_cuerpoVacioResponde400() throws Exception {
        parametro("id", "5");
        cuerpo("{}");
        new ClienteServlet().doPatch(req, resp);
        verify(resp).setStatus(HttpServletResponse.SC_BAD_REQUEST);
        verify(clienteDAO, never()).update(any());
    }

    @Test
    void rojo_patch_tipoInvalidoResponde400() throws Exception {
        sesionDe(usuario(1, 0));
        parametro("id", "3");
        cuerpo("{\"precioVenta\":\"caro\"}");
        Producto guardado = new Producto();
        guardado.setIdProducto(3);
        when(productoDAO.listById(3)).thenReturn(guardado);
        new ProductoServlet().doPatch(req, resp);
        verify(resp).setStatus(HttpServletResponse.SC_BAD_REQUEST);
        verify(productoDAO, never()).update(any());
    }

    @Test
    void rojo_patch_productoSinAdminResponde403() throws Exception {
        sinSesion();
        new ProductoServlet().doPatch(req, resp);
        verify(resp).sendError(HttpServletResponse.SC_FORBIDDEN,
                "Solo los administradores pueden modificar productos.");
        verify(productoDAO, never()).update(any());
    }

    @Test
    void rojo_presupuesto_putYPatchResponden405() throws Exception {
        PresupuestoServlet servlet = new PresupuestoServlet();
        servlet.doPut(req, resp);
        servlet.doPatch(req, resp);
        verify(resp, org.mockito.Mockito.times(2)).setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
    }

    @Test
    void verde_service_derivaPatchADoPatch() throws Exception {
        when(req.getMethod()).thenReturn("PATCH");
        parametro("id", "5");
        cuerpo("{\"email\":\"nuevo@mail.com\"}");
        when(clienteDAO.listById(5)).thenReturn(clienteGuardado());
        when(clienteDAO.update(any())).thenReturn(true);

        new ClienteServlet().service(req, resp);

        verify(clienteDAO).update(any());
    }
}
